"use client"

import { useLocale } from "@/lib/locale-context"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import { Briefcase, Award } from "lucide-react"

export default function AboutPage() {
  const { locale } = useLocale()

  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="flex flex-col md:flex-row gap-8 items-center">
          <div className="w-48 h-48 rounded-full overflow-hidden ring-4 ring-primary/20 ring-offset-4 ring-offset-background shadow-2xl flex-shrink-0">
            <Image
              src="/images/inomjon-profile.jpg"
              alt="Olimov Inomjon"
              width={192}
              height={192}
              className="object-cover w-full h-full"
            />
          </div>
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-4xl font-bold mb-2">Olimov Inomjon</h1>
            <p className="text-xl text-primary font-semibold mb-4">
              {locale === "uz" && "Buxgalter Iqtisodchi"}
              {locale === "ru" && "Бухгалтер-экономист"}
              {locale === "en" && "Accountant-Economist"}
              {locale === "zh" && "会计经济学家"}
            </p>
            <p className="text-muted-foreground">
              {locale === "uz" &&
                "Professional iqtisodiy tahlil, buxgalteriya va zamonaviy texnologiyalar bo'yicha mutaxassis"}
              {locale === "ru" &&
                "Специалист по профессиональному экономическому анализу, бухгалтерии и современным технологиям"}
              {locale === "en" && "Specialist in professional economic analysis, accounting and modern technologies"}
              {locale === "zh" && "专业经济分析、会计和现代技术专家"}
            </p>
          </div>
        </div>

        <Card>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="p-3 rounded-lg bg-blue-100 dark:bg-blue-900/20 h-fit">
                  <Briefcase className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">
                    {locale === "uz" && "Tajriba va Malaka"}
                    {locale === "ru" && "Опыт и квалификация"}
                    {locale === "en" && "Experience and Qualifications"}
                    {locale === "zh" && "经验和资格"}
                  </h3>
                  {locale === "uz" && (
                    <div className="space-y-2 text-muted-foreground">
                      <p>
                        <strong>Buxgalter Iqtisodchi</strong> - Moliyaviy hisobotlar, soliq hisoblari va buxgalteriya
                        hujjatlari bilan ishlashda keng tajriba
                      </p>
                      <p>
                        <strong>1C Buxgalteriya</strong> - 1C dasturida professional darajada ishlash va uni biznes
                        ehtiyojlariga moslash
                      </p>
                      <p>
                        <strong>Avtomatizatsiya dasturlari</strong> - Biznes jarayonlarni avtomatlashtirish va
                        optimallash bo'yicha tajriba
                      </p>
                      <p>
                        <strong>Suniy intellekt integratsiyasi</strong> - AI texnologiyalarini iqtisodiy tahlil va
                        biznes jarayonlariga qo'llash
                      </p>
                    </div>
                  )}
                  {locale === "ru" && (
                    <div className="space-y-2 text-muted-foreground">
                      <p>
                        <strong>Бухгалтер-экономист</strong> - Обширный опыт работы с финансовой отчетностью, налоговым
                        учетом и бухгалтерскими документами
                      </p>
                      <p>
                        <strong>1С Бухгалтерия</strong> - Профессиональная работа в программе 1С и ее адаптация под
                        нужды бизнеса
                      </p>
                      <p>
                        <strong>Программы автоматизации</strong> - Опыт автоматизации и оптимизации бизнес-процессов
                      </p>
                      <p>
                        <strong>Интеграция искусственного интеллекта</strong> - Применение AI технологий в экономическом
                        анализе и бизнес-процессах
                      </p>
                    </div>
                  )}
                  {locale === "en" && (
                    <div className="space-y-2 text-muted-foreground">
                      <p>
                        <strong>Accountant-Economist</strong> - Extensive experience with financial reporting, tax
                        accounting and accounting documents
                      </p>
                      <p>
                        <strong>1C Accounting</strong> - Professional work in 1C software and its adaptation to business
                        needs
                      </p>
                      <p>
                        <strong>Automation programs</strong> - Experience in automating and optimizing business
                        processes
                      </p>
                      <p>
                        <strong>Artificial intelligence integration</strong> - Application of AI technologies in
                        economic analysis and business processes
                      </p>
                    </div>
                  )}
                  {locale === "zh" && (
                    <div className="space-y-2 text-muted-foreground">
                      <p>
                        <strong>会计经济学家</strong> - 在财务报告、税务会计和会计文件方面拥有丰富的经验
                      </p>
                      <p>
                        <strong>1C会计</strong> - 专业使用1C软件并将其适应业务需求
                      </p>
                      <p>
                        <strong>自动化程序</strong> - 在自动化和优化业务流程方面的经验
                      </p>
                      <p>
                        <strong>人工智能集成</strong> - 在经济分析和业务流程中应用人工智能技术
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-4">
                <div className="p-3 rounded-lg bg-cyan-100 dark:bg-cyan-900/20 h-fit">
                  <Award className="h-6 w-6 text-cyan-600 dark:text-cyan-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">
                    {locale === "uz" && "Professional Ko'nikmalar"}
                    {locale === "ru" && "Профессиональные навыки"}
                    {locale === "en" && "Professional Skills"}
                    {locale === "zh" && "专业技能"}
                  </h3>
                  <ul className="space-y-1 text-muted-foreground list-disc list-inside">
                    {locale === "uz" && (
                      <>
                        <li>Moliyaviy tahlil va prognozlash</li>
                        <li>Buxgalteriya hisoboti va soliq hisoblari</li>
                        <li>1C: Buxgalteriya platformasi</li>
                        <li>Biznes jarayonlarni avtomatlashtirish</li>
                        <li>AI va ML texnologiyalar integratsiyasi</li>
                        <li>Data tahlili va visualizatsiya</li>
                      </>
                    )}
                    {locale === "ru" && (
                      <>
                        <li>Финансовый анализ и прогнозирование</li>
                        <li>Бухгалтерская отчетность и налоговый учет</li>
                        <li>Платформа 1С: Бухгалтерия</li>
                        <li>Автоматизация бизнес-процессов</li>
                        <li>Интеграция AI и ML технологий</li>
                        <li>Анализ и визуализация данных</li>
                      </>
                    )}
                    {locale === "en" && (
                      <>
                        <li>Financial analysis and forecasting</li>
                        <li>Accounting reporting and tax accounting</li>
                        <li>1C: Accounting platform</li>
                        <li>Business process automation</li>
                        <li>AI and ML technology integration</li>
                        <li>Data analysis and visualization</li>
                      </>
                    )}
                    {locale === "zh" && (
                      <>
                        <li>财务分析和预测</li>
                        <li>会计报告和税务会计</li>
                        <li>1C：会计平台</li>
                        <li>业务流程自动化</li>
                        <li>AI和ML技术集成</li>
                        <li>数据分析和可视化</li>
                      </>
                    )}
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
