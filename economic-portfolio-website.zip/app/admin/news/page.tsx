"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Plus, Pencil, Trash2 } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function AdminNewsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [news, setNews] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<any>(null)

  const [formData, setFormData] = useState({
    title_uz: "",
    title_ru: "",
    title_en: "",
    content_uz: "",
    content_ru: "",
    content_en: "",
    source: "",
    source_url: "",
    category: "economy",
    region: "global",
  })

  useEffect(() => {
    checkAuth()
    fetchNews()
  }, [])

  const checkAuth = async () => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
    } else {
      setUser(user)
    }
    setLoading(false)
  }

  const fetchNews = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("news_articles").select("*").order("published_at", { ascending: false })

    if (!error && data) {
      setNews(data)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()

    if (editingItem) {
      const { error } = await supabase.from("news_articles").update(formData).eq("id", editingItem.id)

      if (!error) {
        alert("Yangilik yangilandi!")
        fetchNews()
        resetForm()
      }
    } else {
      const { error } = await supabase
        .from("news_articles")
        .insert([{ ...formData, published_at: new Date().toISOString() }])

      if (!error) {
        alert("Yangilik qo'shildi!")
        fetchNews()
        resetForm()
      }
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("O'chirishni tasdiqlaysizmi?")) return

    const supabase = createClient()
    const { error } = await supabase.from("news_articles").delete().eq("id", id)

    if (!error) {
      alert("O'chirildi!")
      fetchNews()
    }
  }

  const handleEdit = (item: any) => {
    setEditingItem(item)
    setFormData(item)
    setIsDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      title_uz: "",
      title_ru: "",
      title_en: "",
      content_uz: "",
      content_ru: "",
      content_en: "",
      source: "",
      source_url: "",
      category: "economy",
      region: "global",
    })
    setEditingItem(null)
    setIsDialogOpen(false)
  }

  if (loading) return <div className="container py-12">Loading...</div>

  return (
    <div className="container py-12">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.push("/admin")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Orqaga
            </Button>
            <h1 className="text-3xl font-bold">Yangiliklar Boshqaruvi</h1>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetForm()}>
                <Plus className="h-4 w-4 mr-2" />
                Yangi Yangilik
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingItem ? "Yangilik Tahrirlash" : "Yangi Yangilik"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Sarlavha (O'zbek)</Label>
                    <Input
                      required
                      value={formData.title_uz}
                      onChange={(e) => setFormData({ ...formData, title_uz: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Sarlavha (Rus)</Label>
                    <Input
                      required
                      value={formData.title_ru}
                      onChange={(e) => setFormData({ ...formData, title_ru: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Matn (O'zbek) - Digest formatda</Label>
                  <Textarea
                    required
                    rows={3}
                    placeholder="Qisqa digest - 2-3 jumla"
                    value={formData.content_uz}
                    onChange={(e) => setFormData({ ...formData, content_uz: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Текст (Rus) - Digest formatda</Label>
                  <Textarea
                    required
                    rows={3}
                    value={formData.content_ru}
                    onChange={(e) => setFormData({ ...formData, content_ru: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Kategoriya</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="economy">Iqtisodiyot</SelectItem>
                        <SelectItem value="finance">Moliya</SelectItem>
                        <SelectItem value="business">Biznes</SelectItem>
                        <SelectItem value="technology">Texnologiya</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Mintaqa</Label>
                    <Select
                      value={formData.region}
                      onValueChange={(value) => setFormData({ ...formData, region: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="global">Jahon</SelectItem>
                        <SelectItem value="uzbekistan">O'zbekiston</SelectItem>
                        <SelectItem value="asia">Osiyo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Manba</Label>
                    <Input
                      required
                      placeholder="Reuters, Kun.uz, etc."
                      value={formData.source}
                      onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Manba URL</Label>
                    <Input
                      type="url"
                      value={formData.source_url}
                      onChange={(e) => setFormData({ ...formData, source_url: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Bekor qilish
                  </Button>
                  <Button type="submit">{editingItem ? "Yangilash" : "Qo'shish"}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {news.map((item) => (
            <Card key={item.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{item.title_uz}</CardTitle>
                    <CardDescription>
                      {item.category} • {item.region} • {item.source}
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(item)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDelete(item.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-2">{item.content_uz}</p>
              </CardContent>
            </Card>
          ))}

          {news.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">Hali yangilik qo'shilmagan.</CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
