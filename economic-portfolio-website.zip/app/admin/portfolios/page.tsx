"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Plus, Pencil, Trash2 } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function AdminPortfoliosPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [portfolios, setPortfolios] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<any>(null)

  const [formData, setFormData] = useState({
    title_uz: "",
    title_ru: "",
    title_en: "",
    title_zh: "",
    description_uz: "",
    description_ru: "",
    description_en: "",
    description_zh: "",
    category: "",
    image_url: "",
    link: "",
  })

  useEffect(() => {
    checkAuth()
    fetchPortfolios()
  }, [])

  const checkAuth = async () => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
    } else {
      setUser(user)
    }
    setLoading(false)
  }

  const fetchPortfolios = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("portfolios").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setPortfolios(data)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()

    if (editingItem) {
      // Update existing
      const { error } = await supabase.from("portfolios").update(formData).eq("id", editingItem.id)

      if (!error) {
        alert("Portfolio yangilandi!")
        fetchPortfolios()
        resetForm()
      }
    } else {
      // Create new
      const { error } = await supabase.from("portfolios").insert([{ ...formData, user_id: user.id }])

      if (!error) {
        alert("Portfolio qo'shildi!")
        fetchPortfolios()
        resetForm()
      }
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("O'chirishni tasdiqlaysizmi?")) return

    const supabase = createClient()
    const { error } = await supabase.from("portfolios").delete().eq("id", id)

    if (!error) {
      alert("O'chirildi!")
      fetchPortfolios()
    }
  }

  const handleEdit = (item: any) => {
    setEditingItem(item)
    setFormData(item)
    setIsDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      title_uz: "",
      title_ru: "",
      title_en: "",
      title_zh: "",
      description_uz: "",
      description_ru: "",
      description_en: "",
      description_zh: "",
      category: "",
      image_url: "",
      link: "",
    })
    setEditingItem(null)
    setIsDialogOpen(false)
  }

  if (loading) return <div className="container py-12">Loading...</div>

  return (
    <div className="container py-12">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.push("/admin")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Orqaga
            </Button>
            <h1 className="text-3xl font-bold">Portfolio Boshqaruvi</h1>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetForm()}>
                <Plus className="h-4 w-4 mr-2" />
                Yangi Portfolio
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingItem ? "Portfolio Tahrirlash" : "Yangi Portfolio"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Sarlavha (O'zbek)</Label>
                    <Input
                      required
                      value={formData.title_uz}
                      onChange={(e) => setFormData({ ...formData, title_uz: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Sarlavha (Rus)</Label>
                    <Input
                      required
                      value={formData.title_ru}
                      onChange={(e) => setFormData({ ...formData, title_ru: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Title (English)</Label>
                    <Input
                      required
                      value={formData.title_en}
                      onChange={(e) => setFormData({ ...formData, title_en: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>标题 (Chinese)</Label>
                    <Input
                      value={formData.title_zh}
                      onChange={(e) => setFormData({ ...formData, title_zh: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Tavsif (O'zbek)</Label>
                  <Textarea
                    required
                    rows={3}
                    value={formData.description_uz}
                    onChange={(e) => setFormData({ ...formData, description_uz: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Описание (Rus)</Label>
                  <Textarea
                    required
                    rows={3}
                    value={formData.description_ru}
                    onChange={(e) => setFormData({ ...formData, description_ru: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description (English)</Label>
                  <Textarea
                    required
                    rows={3}
                    value={formData.description_en}
                    onChange={(e) => setFormData({ ...formData, description_en: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Kategoriya</Label>
                    <Input
                      required
                      placeholder="Masalan: Automation, AI, Finance"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Rasm URL</Label>
                    <Input
                      type="url"
                      placeholder="https://example.com/image.jpg"
                      value={formData.image_url}
                      onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Link (ixtiyoriy)</Label>
                  <Input
                    type="url"
                    placeholder="https://example.com"
                    value={formData.link}
                    onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                  />
                </div>

                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Bekor qilish
                  </Button>
                  <Button type="submit">{editingItem ? "Yangilash" : "Qo'shish"}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {portfolios.map((item) => (
            <Card key={item.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{item.title_uz}</CardTitle>
                    <CardDescription>{item.category}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(item)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDelete(item.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-2">{item.description_uz}</p>
              </CardContent>
            </Card>
          ))}

          {portfolios.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                Hali portfolio qo'shilmagan. "Yangi Portfolio" tugmasini bosing.
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
