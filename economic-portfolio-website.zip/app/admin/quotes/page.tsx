"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Plus, Pencil, Trash2 } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function AdminQuotesPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [quotes, setQuotes] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<any>(null)

  const [formData, setFormData] = useState({
    quote_uz: "",
    quote_ru: "",
    quote_en: "",
    author_uz: "",
    author_ru: "",
    author_en: "",
    author_title_uz: "",
    author_title_ru: "",
    author_title_en: "",
  })

  useEffect(() => {
    checkAuth()
    fetchQuotes()
  }, [])

  const checkAuth = async () => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
    } else {
      setUser(user)
    }
    setLoading(false)
  }

  const fetchQuotes = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("quotes").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setQuotes(data)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()

    if (editingItem) {
      const { error } = await supabase.from("quotes").update(formData).eq("id", editingItem.id)

      if (!error) {
        alert("Iqtibos yangilandi!")
        fetchQuotes()
        resetForm()
      }
    } else {
      const { error } = await supabase.from("quotes").insert([formData])

      if (!error) {
        alert("Iqtibos qo'shildi!")
        fetchQuotes()
        resetForm()
      }
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("O'chirishni tasdiqlaysizmi?")) return

    const supabase = createClient()
    const { error } = await supabase.from("quotes").delete().eq("id", id)

    if (!error) {
      alert("O'chirildi!")
      fetchQuotes()
    }
  }

  const handleEdit = (item: any) => {
    setEditingItem(item)
    setFormData(item)
    setIsDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      quote_uz: "",
      quote_ru: "",
      quote_en: "",
      author_uz: "",
      author_ru: "",
      author_en: "",
      author_title_uz: "",
      author_title_ru: "",
      author_title_en: "",
    })
    setEditingItem(null)
    setIsDialogOpen(false)
  }

  if (loading) return <div className="container py-12">Loading...</div>

  return (
    <div className="container py-12">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.push("/admin")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Orqaga
            </Button>
            <h1 className="text-3xl font-bold">Hikmatli So'zlar Boshqaruvi</h1>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetForm()}>
                <Plus className="h-4 w-4 mr-2" />
                Yangi Iqtibos
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingItem ? "Iqtibos Tahrirlash" : "Yangi Iqtibos"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Iqtibos (O'zbek)</Label>
                  <Textarea
                    required
                    rows={3}
                    value={formData.quote_uz}
                    onChange={(e) => setFormData({ ...formData, quote_uz: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Цитата (Rus)</Label>
                  <Textarea
                    required
                    rows={3}
                    value={formData.quote_ru}
                    onChange={(e) => setFormData({ ...formData, quote_ru: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Quote (English)</Label>
                  <Textarea
                    required
                    rows={3}
                    value={formData.quote_en}
                    onChange={(e) => setFormData({ ...formData, quote_en: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Muallif (O'zbek)</Label>
                    <Input
                      required
                      value={formData.author_uz}
                      onChange={(e) => setFormData({ ...formData, author_uz: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Автор (Rus)</Label>
                    <Input
                      required
                      value={formData.author_ru}
                      onChange={(e) => setFormData({ ...formData, author_ru: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Author (English)</Label>
                    <Input
                      required
                      value={formData.author_en}
                      onChange={(e) => setFormData({ ...formData, author_en: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Lavozim (O'zbek)</Label>
                    <Input
                      placeholder="Iqtisodchi, Olim"
                      value={formData.author_title_uz}
                      onChange={(e) => setFormData({ ...formData, author_title_uz: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Должность (Rus)</Label>
                    <Input
                      value={formData.author_title_ru}
                      onChange={(e) => setFormData({ ...formData, author_title_ru: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Title (English)</Label>
                    <Input
                      value={formData.author_title_en}
                      onChange={(e) => setFormData({ ...formData, author_title_en: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Bekor qilish
                  </Button>
                  <Button type="submit">{editingItem ? "Yangilash" : "Qo'shish"}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {quotes.map((item) => (
            <Card key={item.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardDescription className="mb-2 italic">"{item.quote_uz}"</CardDescription>
                    <CardTitle className="text-base">
                      - {item.author_uz}
                      {item.author_title_uz && (
                        <span className="text-muted-foreground font-normal">, {item.author_title_uz}</span>
                      )}
                    </CardTitle>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(item)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDelete(item.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}

          {quotes.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">Hali iqtibos qo'shilmagan.</CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
