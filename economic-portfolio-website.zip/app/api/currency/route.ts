import { NextResponse } from "next/server"
import { getCurrencyRates } from "@/lib/api/currency"

export async function GET() {
  try {
    const rates = await getCurrencyRates()
    return NextResponse.json(rates)
  } catch (error) {
    console.error("[v0] Currency API error:", error)
    return NextResponse.json({ error: "Failed to fetch currency rates" }, { status: 500 })
  }
}
