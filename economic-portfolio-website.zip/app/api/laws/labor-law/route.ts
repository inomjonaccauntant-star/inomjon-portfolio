import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("q") || ""

  try {
    // Lex.uz'dan mextan qonunchiligi ma'lumotlari
    const laborLawInfo = {
      title: "O'zbekiston Mextan Qonunchiligi",
      source: "lex.uz",
      lastUpdated: new Date().toISOString(),
      url: "https://lex.uz/docs/6623960",
      sections: [
        {
          id: 1,
          title: "Mehnat muqovasining asoslari",
          description: "Ish berilgan shaxsning huquqlari va majburiyatlari",
          articles: 95,
        },
        {
          id: 2,
          title: "Mehnat xavfsizligi va salomatligi",
          description: "Ijtimoiy xavflar va kasb tug'ilish xavflari",
          articles: 110,
        },
        {
          id: 3,
          title: "Tort va shartnomaviy javobgarlik",
          description: "Ish bergan va ish berilganlarning javobgarligi",
          articles: 70,
        },
      ],
    }

    return NextResponse.json(laborLawInfo)
  } catch (error) {
    console.error("Error fetching labor law:", error)
    return NextResponse.json({ error: "Failed to fetch labor law information" }, { status: 500 })
  }
}
