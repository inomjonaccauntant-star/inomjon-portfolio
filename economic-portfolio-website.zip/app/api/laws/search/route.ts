import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("q") || ""

  try {
    // Qidirish natijalarini qaytarish
    const searchResults = {
      query: query,
      results: [
        {
          id: 1,
          type: "tax",
          title: "Soliq Kodeksida soliqlanish",
          snippet: "Yuridik va jismoniy shaxslarning soliq majburiyatlari",
          source: "lex.uz",
          url: "https://lex.uz/docs/12987900",
          relevance: 0.95,
        },
        {
          id: 2,
          type: "labor",
          title: "Mehnat muqovasi va shartlari",
          snippet: "Ish bergan va ish berilgan o'rtasidagi huquq va majburiyatlar",
          source: "lex.uz",
          url: "https://lex.uz/docs/6623960",
          relevance: 0.88,
        },
        {
          id: 3,
          type: "tax",
          title: "VAT soliqining asoslari",
          snippet: "Qo'shimcha narxi soliqining hisoblash va to'lash tartibi",
          source: "lex.uz",
          url: "https://lex.uz/docs/12987900",
          relevance: 0.82,
        },
      ],
      totalResults: 250,
      executionTime: "0.45s",
    }

    return NextResponse.json(searchResults)
  } catch (error) {
    console.error("Error searching laws:", error)
    return NextResponse.json({ error: "Failed to search laws" }, { status: 500 })
  }
}
