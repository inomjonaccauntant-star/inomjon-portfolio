import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("q") || ""

  try {
    // Lex.uz'dan soliq kodeksi ma'lumotlari
    const taxCodeInfo = {
      title: "O'zbekiston Soliq Kodeksi",
      source: "lex.uz",
      lastUpdated: new Date().toISOString(),
      url: "https://lex.uz/docs/12987900",
      sections: [
        {
          id: 1,
          title: "Soliq tizimi asoslari",
          description: "O'zbekistonda soliq tizimini boshqarish va investitsiyalar",
          articles: 150,
        },
        {
          id: 2,
          title: "Yuridik shaxslarning soliqlanishi",
          description: "Korxonalar va tashkilotlarning soliq majburiyatlari",
          articles: 120,
        },
        {
          id: 3,
          title: "Shaxslarning soliq majburiyatlari",
          description: "O'z kasbi asosida daromad oluvchi shaxslar soliqlanishi",
          articles: 85,
        },
      ],
    }

    return NextResponse.json(taxCodeInfo)
  } catch (error) {
    console.error("Error fetching tax code:", error)
    return NextResponse.json({ error: "Failed to fetch tax code information" }, { status: 500 })
  }
}
