import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST() {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // In a real implementation, this would call AI APIs (Gemini, ChatGPT, etc.)
    // to generate economic news. For now, we'll create sample data.

    const sampleNews = [
      {
        title_uz: "O'zbekiston Markaziy Banki asosiy stavkani o'zgartirdi",
        title_ru: "Центральный банк Узбекистана изменил ключевую ставку",
        title_en: "Central Bank of Uzbekistan Changed Key Rate",
        title_zh: "乌兹别克斯坦中央银行改变关键利率",
        content_uz:
          "O'zbekiston Respublikasi Markaziy banki asosiy stavkani 14% darajasida ushlab turish to'g'risida qaror qabul qildi. Bu qaror inflyatsiya darajasini nazorat qilish va iqtisodiy barqarorlikni ta'minlash maqsadida qabul qilingan.",
        content_ru:
          "Центральный банк Республики Узбекистан принял решение сохранить ключевую ставку на уровне 14%. Это решение принято с целью контроля уровня инфляции и обеспечения экономической стабильности.",
        content_en:
          "The Central Bank of the Republic of Uzbekistan decided to maintain the key rate at 14%. This decision was made to control inflation and ensure economic stability.",
        content_zh: "乌兹别克斯坦共和国中央银行决定将关键利率维持在14%。此决定旨在控制通货膨胀并确保经济稳定。",
        category: "Monetary Policy",
        region: "Uzbekistan",
        source: "CBU",
        ai_generated: true,
        published_at: new Date().toISOString(),
      },
      {
        title_uz: "Jahon iqtisodiyoti 2024 yilda 3.2% o'sdi",
        title_ru: "Мировая экономика выросла на 3.2% в 2024 году",
        title_en: "Global Economy Grew 3.2% in 2024",
        title_zh: "2024年全球经济增长3.2%",
        content_uz:
          "Xalqaro Valyuta Fondi ma'lumotlariga ko'ra, 2024 yilda jahon iqtisodiyoti 3.2% o'sdi. Rivojlanayotgan bozorlar va rivojlangan mamlakatlar o'rtasida o'sish sur'ati farq qildi.",
        content_ru:
          "По данным Международного валютного фонда, мировая экономика выросла на 3.2% в 2024 году. Темпы роста различались между развивающимися рынками и развитыми странами.",
        content_en:
          "According to the International Monetary Fund, the global economy grew 3.2% in 2024. Growth rates varied between emerging markets and developed countries.",
        content_zh: "根据国际货币基金组织的数据，2024年全球经济增长了3.2%。新兴市场和发达国家之间的增长率有所不同。",
        category: "Global Economy",
        region: "World",
        source: "IMF",
        ai_generated: true,
        published_at: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
      },
    ]

    // Insert sample news
    const { data, error } = await supabase.from("news_articles").insert(sampleNews).select()

    if (error) throw error

    return NextResponse.json({ success: true, count: data?.length || 0 })
  } catch (error) {
    console.error("[v0] News generation error:", error)
    return NextResponse.json({ error: "Failed to generate news" }, { status: 500 })
  }
}
