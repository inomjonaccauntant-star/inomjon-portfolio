import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = await createClient()

    console.log("[v0] Fetching news from database...")

    const { data, error } = await supabase
      .from("news_articles")
      .select("*")
      .order("published_at", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(20)

    if (error) {
      console.error("[v0] News database error:", error)
      throw error
    }

    console.log("[v0] News articles fetched:", data?.length || 0)

    return NextResponse.json(data || [])
  } catch (error) {
    console.error("[v0] News API error:", error)
    return NextResponse.json([])
  }
}
