import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = await createClient()

    const { data, error } = await supabase
      .from("portfolios")
      .select("*")
      .eq("published", true)
      .order("created_at", { ascending: false })

    if (error) throw error

    return NextResponse.json(data || [])
  } catch (error) {
    console.error("[v0] Portfolios API error:", error)
    return NextResponse.json({ error: "Failed to fetch portfolios" }, { status: 500 })
  }
}
