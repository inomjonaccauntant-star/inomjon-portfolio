import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = await createClient()

    console.log("[v0] Fetching quotes from database...")

    const { data, error } = await supabase
      .from("quotes")
      .select("*")
      .eq("is_active", true)
      .order("created_at", { ascending: false })
      .limit(10)

    if (error) {
      console.error("[v0] Quote database error:", error)
      throw error
    }

    console.log("[v0] Quotes fetched:", data?.length || 0)

    if (!data || data.length === 0) {
      return NextResponse.json({
        id: "fallback",
        author_uz: "Adam Smit",
        author_ru: "Адам Смит",
        author_en: "Adam Smith",
        author_zh: "亚当·斯密",
        text_uz: "Iqtisodiyot - bu odamlarning o'z manfaatlariga erishish yo'lidagi harakati.",
        text_ru: "Экономика - это движение людей к достижению своих интересов.",
        text_en: "Economics is the movement of people towards achieving their interests.",
        text_zh: "经济学是人们实现自身利益的运动。",
        is_active: true,
        created_at: new Date().toISOString(),
      })
    }

    const randomQuote = data[Math.floor(Math.random() * data.length)]
    return NextResponse.json(randomQuote)
  } catch (error) {
    console.error("[v0] Quote API error:", error)
    return NextResponse.json({
      id: "fallback",
      author_uz: "Adam Smit",
      author_ru: "Адам Смит",
      author_en: "Adam Smith",
      author_zh: "亚当·斯密",
      text_uz: "Iqtisodiyot - bu odamlarning o'z manfaatlariga erishish yo'lidagi harakati.",
      text_ru: "Экономика - это движение людей к достижению своих интересов.",
      text_en: "Economics is the movement of people towards achieving their interests.",
      text_zh: "经济学是人们实现自身利益的运动。",
      is_active: true,
      created_at: new Date().toISOString(),
    })
  }
}
