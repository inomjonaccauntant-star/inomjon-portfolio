import { NextResponse } from "next/server"

export async function GET() {
  try {
    const stats = {
      world: {
        gdp: { value: "96.5", unit: "trillion USD", change: 2.4 },
        population: { value: "8.1", unit: "billion", change: 0.9 },
        unemployment: { value: "5.2", unit: "%", change: -0.3 },
        inflation: { value: "3.1", unit: "%", change: -0.8 },
      },
      uzbekistan: {
        gdp: { value: "92.1", unit: "billion USD", change: 5.2 },
        population: { value: "36.6", unit: "million", change: 1.2 },
        unemployment: { value: "5.9", unit: "%", change: -0.4 },
        inflation: { value: "12.3", unit: "%", change: 2.1 },
      },
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Error fetching global statistics:", error)
    return NextResponse.json({ error: "Failed to fetch statistics" }, { status: 500 })
  }
}
