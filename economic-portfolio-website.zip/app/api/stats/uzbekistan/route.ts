import { NextResponse } from "next/server"
import { UZBEKISTAN_STATS } from "@/lib/api/uzbekistan-stats"

export async function GET() {
  try {
    return NextResponse.json(UZBEKISTAN_STATS)
  } catch (error) {
    console.error("[v0] Uzbekistan stats API error:", error)
    return NextResponse.json({ error: "Failed to fetch statistics" }, { status: 500 })
  }
}
