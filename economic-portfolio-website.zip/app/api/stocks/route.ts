import { NextResponse } from "next/server"
import { getStockPrices } from "@/lib/api/stock-market"

export async function GET() {
  try {
    const stocks = await getStockPrices()
    return NextResponse.json(stocks)
  } catch (error) {
    console.error("[v0] Stocks API error:", error)
    return NextResponse.json({ error: "Failed to fetch stock prices" }, { status: 500 })
  }
}
