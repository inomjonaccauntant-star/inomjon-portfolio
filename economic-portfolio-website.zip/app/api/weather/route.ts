import { NextResponse } from "next/server"
import { getWeather } from "@/lib/api/weather"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const city = searchParams.get("city") || "Fergana"

    const weather = await getWeather(city)
    return NextResponse.json(weather)
  } catch (error) {
    console.error("[v0] Weather API error:", error)
    return NextResponse.json({ error: "Failed to fetch weather data" }, { status: 500 })
  }
}
