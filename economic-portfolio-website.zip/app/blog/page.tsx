"use client"

import { useEffect, useState } from "react"
import { useLocale } from "@/lib/locale-context"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Eye, Search } from "lucide-react"
import Link from "next/link"
import type { BlogPost } from "@/lib/types"

export default function BlogPage() {
  const { locale } = useLocale()
  const [posts, setPosts] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await fetch("/api/blog")
        const data = await response.json()
        setPosts(data)
      } catch (error) {
        console.error("[v0] Error loading blog posts:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPosts()
  }, [])

  const filteredPosts = posts.filter((post) => {
    const matchesSearch =
      searchQuery === "" ||
      post[`title_${locale}` as keyof BlogPost]?.toString().toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = !selectedCategory || post.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  const categories = Array.from(new Set(posts.map((p) => p.category)))

  const getTitle = (post: BlogPost) => {
    return post[`title_${locale}` as keyof BlogPost] || post.title_uz
  }

  const getExcerpt = (post: BlogPost) => {
    return post[`excerpt_${locale}` as keyof BlogPost] || post.excerpt_uz
  }

  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold">
            {locale === "uz" && "Blog"}
            {locale === "ru" && "Блог"}
            {locale === "en" && "Blog"}
            {locale === "zh" && "博客"}
          </h1>
          <p className="text-xl text-muted-foreground">
            {locale === "uz" && "Iqtisodiyot haqida maqolalar va tahlillar"}
            {locale === "ru" && "Статьи и анализы об экономике"}
            {locale === "en" && "Articles and analysis about economics"}
            {locale === "zh" && "关于经济的文章和分析"}
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={
                locale === "uz" ? "Maqolalarni qidirish..." : locale === "ru" ? "Поиск статей..." : "Search articles..."
              }
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(null)}
            >
              {locale === "uz" && "Hammasi"}
              {locale === "ru" && "Все"}
              {locale === "en" && "All"}
              {locale === "zh" && "全部"}
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Blog Posts List */}
        {loading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="pt-6">
                  <div className="flex gap-6">
                    <div className="w-48 h-32 bg-muted animate-pulse rounded-lg shrink-0" />
                    <div className="flex-1 space-y-3">
                      <div className="h-6 bg-muted animate-pulse rounded w-3/4" />
                      <div className="h-4 bg-muted animate-pulse rounded" />
                      <div className="h-4 bg-muted animate-pulse rounded w-5/6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredPosts.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-muted-foreground">
                {locale === "uz" && "Maqolalar topilmadi"}
                {locale === "ru" && "Статьи не найдены"}
                {locale === "en" && "No articles found"}
                {locale === "zh" && "未找到文章"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {filteredPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <Link href={`/blog/${post.id}`}>
                    <div className="flex flex-col md:flex-row gap-6">
                      {post.cover_image_url ? (
                        <div className="w-full md:w-48 h-48 md:h-32 shrink-0 rounded-lg overflow-hidden">
                          <img
                            src={post.cover_image_url || "/placeholder.svg"}
                            alt={getTitle(post)?.toString()}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      ) : (
                        <div className="w-full md:w-48 h-48 md:h-32 shrink-0 rounded-lg bg-gradient-to-br from-blue-100 to-cyan-100 dark:from-blue-900/20 dark:to-cyan-900/20 flex items-center justify-center">
                          <span className="text-3xl font-bold text-muted-foreground">
                            {getTitle(post)?.toString().charAt(0)}
                          </span>
                        </div>
                      )}
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="secondary">{post.category}</Badge>
                          {post.tags &&
                            post.tags.slice(0, 2).map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                        </div>
                        <h2 className="text-2xl font-semibold hover:text-primary transition-colors">
                          {getTitle(post)?.toString()}
                        </h2>
                        <p className="text-muted-foreground line-clamp-2">{getExcerpt(post)?.toString()}</p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {new Date(post.created_at).toLocaleDateString(locale)}
                          </div>
                          {post.reading_time && (
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {post.reading_time}{" "}
                              {locale === "uz" ? "daqiqa" : locale === "ru" ? "мин" : locale === "en" ? "min" : "分钟"}
                            </div>
                          )}
                          <div className="flex items-center gap-1">
                            <Eye className="h-4 w-4" />
                            {post.views_count}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
