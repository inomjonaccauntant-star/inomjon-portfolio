"use client"

import { useLocale } from "@/lib/locale-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Mail, Send, Instagram } from "lucide-react"

export default function ContactPage() {
  const { locale } = useLocale()

  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="space-y-4 text-center">
          <h1 className="text-4xl font-bold">
            {locale === "uz" && "Bog'lanish"}
            {locale === "ru" && "Связаться"}
            {locale === "en" && "Get in Touch"}
            {locale === "zh" && "联系我"}
          </h1>
          <p className="text-xl text-muted-foreground">
            {locale === "uz" && "Savollaringiz bo'lsa, men bilan bog'laning"}
            {locale === "ru" && "Если у вас есть вопросы, свяжитесь со мной"}
            {locale === "en" && "If you have any questions, feel free to reach out"}
            {locale === "zh" && "如有任何问题，请随时联系"}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>
                {locale === "uz" && "Xabar yuborish"}
                {locale === "ru" && "Отправить сообщение"}
                {locale === "en" && "Send a Message"}
                {locale === "zh" && "发送消息"}
              </CardTitle>
              <CardDescription>
                {locale === "uz" && "Formani to'ldiring va men siz bilan tez orada bog'lanamiz"}
                {locale === "ru" && "Заполните форму и я свяжусь с вами в ближайшее время"}
                {locale === "en" && "Fill out the form and I will get back to you soon"}
                {locale === "zh" && "填写表格，我会尽快与您联系"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    {locale === "uz" && "Ism"}
                    {locale === "ru" && "Имя"}
                    {locale === "en" && "Name"}
                    {locale === "zh" && "姓名"}
                  </Label>
                  <Input id="name" placeholder={locale === "uz" ? "Ismingiz" : "Your name"} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="your@email.com" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">
                    {locale === "uz" && "Xabar"}
                    {locale === "ru" && "Сообщение"}
                    {locale === "en" && "Message"}
                    {locale === "zh" && "消息"}
                  </Label>
                  <Textarea
                    id="message"
                    rows={5}
                    placeholder={
                      locale === "uz"
                        ? "Xabaringizni yozing..."
                        : locale === "ru"
                          ? "Напишите ваше сообщение..."
                          : "Write your message..."
                    }
                  />
                </div>
                <Button type="submit" className="w-full">
                  {locale === "uz" && "Yuborish"}
                  {locale === "ru" && "Отправить"}
                  {locale === "en" && "Send"}
                  {locale === "zh" && "发送"}
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Email</h3>
                    <a
                      href="mailto:Inomjonaccauntant@gmail.com"
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      Inomjonaccauntant@gmail.com
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Send className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Telegram</h3>
                    <a
                      href="https://t.me/inomjon_olimov"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      @inomjon_olimov
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Instagram className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Instagram</h3>
                    <a
                      href="https://instagram.com/inomjon_accountant"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      @inomjon_accountant
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20 border-primary/20">
              <CardContent className="pt-6">
                <p className="text-sm text-center">
                  {locale === "uz" &&
                    "Professional iqtisodiy maslahat va hamkorlik uchun yuqoridagi aloqa ma'lumotlari orqali bog'laning"}
                  {locale === "ru" &&
                    "Свяжитесь через указанные контакты для профессиональных экономических консультаций и сотрудничества"}
                  {locale === "en" &&
                    "Contact via the information above for professional economic consulting and collaboration"}
                  {locale === "zh" && "通过上述信息联系以获得专业的经济咨询和合作"}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
