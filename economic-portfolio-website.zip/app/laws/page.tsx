"use client"

import { useState } from "react"
import { useLocale } from "@/lib/locale-context"
import { getTranslation } from "@/lib/i18n"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Search, BookOpen, Briefcase } from "lucide-react"
import Link from "next/link"

export default function LawsPage() {
  const { locale } = useLocale()
  const t = getTranslation(locale)
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("tax")

  const pageTitle = {
    uz: "O'zbekiston Qonunchligi",
    ru: "Законодательство Узбекистана",
    en: "Uzbekistan Legislation",
    zh: "乌兹别克斯坦法律",
  }

  const descriptions = {
    uz: "O'zbekiston Respublikasining asosiy qonunlari va kodekslari",
    ru: "Основные законы и кодексы Республики Узбекистан",
    en: "Main laws and codes of the Republic of Uzbekistan",
    zh: "乌兹别克斯坦共和国的主要法律和法典",
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative py-12 md:py-20 overflow-hidden bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20">
        <div className="container">
          <ScrollReveal>
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold text-balance">
                {pageTitle[locale as keyof typeof pageTitle]}
              </h1>
              <p className="text-lg text-muted-foreground">{descriptions[locale as keyof typeof descriptions]}</p>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Main Content */}
      <section className="flex-1 py-12 md:py-16">
        <div className="container">
          <Tabs defaultValue="tax" className="space-y-6" onValueChange={setActiveTab}>
            {/* Tabs Navigation */}
            <ScrollReveal>
              <TabsList className="grid w-full grid-cols-2 bg-muted">
                <TabsTrigger value="tax" className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4" />
                  {locale === "uz" && "Soliq Kodeksi"}
                  {locale === "ru" && "Налоговый кодекс"}
                  {locale === "en" && "Tax Code"}
                  {locale === "zh" && "税法"}
                </TabsTrigger>
                <TabsTrigger value="labor" className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  {locale === "uz" && "Mexnat Qonunchiligi"}
                  {locale === "ru" && "Трудовое законодательство"}
                  {locale === "en" && "Labor Law"}
                  {locale === "zh" && "劳动法"}
                </TabsTrigger>
              </TabsList>
            </ScrollReveal>

            {/* Tax Code Tab */}
            <TabsContent value="tax" className="space-y-6">
              <ScrollReveal>
                <Card className="border-blue-200 dark:border-blue-800">
                  <CardHeader className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30">
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="w-5 h-5 text-blue-600" />
                      {locale === "uz" && "O'zbekiston Soliq Kodeksi"}
                      {locale === "ru" && "Налоговый кодекс Узбекистана"}
                      {locale === "en" && "Uzbekistan Tax Code"}
                      {locale === "zh" && "乌兹别克斯坦税法"}
                    </CardTitle>
                    <CardDescription>
                      {locale === "uz" && "Lex.uz saytidan yangilangan ma'lumotlar"}
                      {locale === "ru" && "Актуальная информация с сайта lex.uz"}
                      {locale === "en" && "Current information from lex.uz"}
                      {locale === "zh" && "来自lex.uz的最新信息"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6 space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder={
                          locale === "uz"
                            ? "Qidirish..."
                            : locale === "ru"
                              ? "Поиск..."
                              : locale === "en"
                                ? "Search..."
                                : "搜索..."
                        }
                        className="pl-10"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="p-4 border rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/20 transition-colors cursor-pointer">
                        <h3 className="font-semibold text-blue-900 dark:text-blue-100">
                          {locale === "uz" && "I. Soliq tizimi"}
                          {locale === "ru" && "I. Налоговая система"}
                          {locale === "en" && "I. Tax System"}
                          {locale === "zh" && "I. 税收制度"}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {locale === "uz" && "O'zbekistonda soliq tizimini boshqarish va investitsiyalar"}
                          {locale === "ru" && "Управление налоговой системой и инвестициями в Узбекистане"}
                          {locale === "en" && "Tax system management and investments in Uzbekistan"}
                          {locale === "zh" && "乌兹别克斯坦的税收制度管理和投资"}
                        </p>
                      </div>

                      <div className="p-4 border rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/20 transition-colors cursor-pointer">
                        <h3 className="font-semibold text-blue-900 dark:text-blue-100">
                          {locale === "uz" && "II. Yuridik shaxslarning soliqlanishi"}
                          {locale === "ru" && "II. Налогообложение юридических лиц"}
                          {locale === "en" && "II. Taxation of Legal Entities"}
                          {locale === "zh" && "II. 法人税"}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {locale === "uz" && "Korxonalar va tashkilotlarning soliq majburiyatlari"}
                          {locale === "ru" && "Налоговые обязательства предприятий и организаций"}
                          {locale === "en" && "Tax obligations of enterprises and organizations"}
                          {locale === "zh" && "企业和组织的税务义务"}
                        </p>
                      </div>

                      <div className="p-4 border rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/20 transition-colors cursor-pointer">
                        <h3 className="font-semibold text-blue-900 dark:text-blue-100">
                          {locale === "uz" && "III. Shaxslarning soliq majburiyatlari"}
                          {locale === "ru" && "III. Налоговые обязательства физических лиц"}
                          {locale === "en" && "III. Taxation of Individuals"}
                          {locale === "zh" && "III. 个人税务义务"}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {locale === "uz" && "O'z kasbi asosida daromad oluvchi shaxslar soliqlanishi"}
                          {locale === "ru" && "Налогообложение лиц, получающих доход от деятельности"}
                          {locale === "en" && "Taxation of individuals earning income from activities"}
                          {locale === "zh" && "从业务中赚取收入的个人税"}
                        </p>
                      </div>
                    </div>

                    <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                      <Link href="https://lex.uz/docs/12987900" target="_blank" rel="noopener noreferrer">
                        {locale === "uz" && "Lex.uz'da to'liq ma'lumot"}
                        {locale === "ru" && "Полная информация на lex.uz"}
                        {locale === "en" && "Full information on lex.uz"}
                        {locale === "zh" && "在lex.uz上获取完整信息"}
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </ScrollReveal>
            </TabsContent>

            {/* Labor Law Tab */}
            <TabsContent value="labor" className="space-y-6">
              <ScrollReveal>
                <Card className="border-cyan-200 dark:border-cyan-800">
                  <CardHeader className="bg-gradient-to-r from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30">
                    <CardTitle className="flex items-center gap-2">
                      <Briefcase className="w-5 h-5 text-cyan-600" />
                      {locale === "uz" && "O'zbekiston Mextan Qonunchiligi"}
                      {locale === "ru" && "Трудовое законодательство Узбекистана"}
                      {locale === "en" && "Uzbekistan Labor Legislation"}
                      {locale === "zh" && "乌兹别克斯坦劳动法"}
                    </CardTitle>
                    <CardDescription>
                      {locale === "uz" && "Mehnat xavfsizligi va ish muhimi"}
                      {locale === "ru" && "Безопасность труда и условия работы"}
                      {locale === "en" && "Labor safety and working conditions"}
                      {locale === "zh" && "劳动安全和工作条件"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6 space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder={
                          locale === "uz"
                            ? "Qidirish..."
                            : locale === "ru"
                              ? "Поиск..."
                              : locale === "en"
                                ? "Search..."
                                : "搜索..."
                        }
                        className="pl-10"
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="p-4 border rounded-lg hover:bg-cyan-50 dark:hover:bg-cyan-950/20 transition-colors cursor-pointer">
                        <h3 className="font-semibold text-cyan-900 dark:text-cyan-100">
                          {locale === "uz" && "Mehnat muqovasining asoslari"}
                          {locale === "ru" && "Основы трудовых отношений"}
                          {locale === "en" && "Fundamentals of Labor Relations"}
                          {locale === "zh" && "劳动关系的基础"}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {locale === "uz" && "Ish berilgan shaxsning huquqlari va majburiyatlari"}
                          {locale === "ru" && "Права и обязанности работников"}
                          {locale === "en" && "Rights and obligations of employees"}
                          {locale === "zh" && "员工的权利和义务"}
                        </p>
                      </div>

                      <div className="p-4 border rounded-lg hover:bg-cyan-50 dark:hover:bg-cyan-950/20 transition-colors cursor-pointer">
                        <h3 className="font-semibold text-cyan-900 dark:text-cyan-100">
                          {locale === "uz" && "Mehnat xavfsizligi va salomatligi"}
                          {locale === "ru" && "Безопасность и охрана труда"}
                          {locale === "en" && "Labor Safety and Protection"}
                          {locale === "zh" && "劳动保护和安全"}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {locale === "uz" && "Ijtimoiy xavflar va kasb tug'ilish xavflari"}
                          {locale === "ru" && "Социальные риски и профессиональные опасности"}
                          {locale === "en" && "Social risks and occupational hazards"}
                          {locale === "zh" && "社会风险和职业危害"}
                        </p>
                      </div>

                      <div className="p-4 border rounded-lg hover:bg-cyan-50 dark:hover:bg-cyan-950/20 transition-colors cursor-pointer">
                        <h3 className="font-semibold text-cyan-900 dark:text-cyan-100">
                          {locale === "uz" && "Tort va shartnomaviy javobgarlik"}
                          {locale === "ru" && "Деликтная и договорная ответственность"}
                          {locale === "en" && "Tort and Contractual Liability"}
                          {locale === "zh" && "侵权和契约责任"}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {locale === "uz" && "Ish bergan va ish berilganlarning javobgarligi"}
                          {locale === "ru" && "Ответственность работодателя и работника"}
                          {locale === "en" && "Employer and employee liability"}
                          {locale === "zh" && "雇主和员工责任"}
                        </p>
                      </div>
                    </div>

                    <Button asChild className="w-full bg-cyan-600 hover:bg-cyan-700">
                      <Link href="https://lex.uz/docs/6623960" target="_blank" rel="noopener noreferrer">
                        {locale === "uz" && "Lex.uz'da to'liq ma'lumot"}
                        {locale === "ru" && "Полная информация на lex.uz"}
                        {locale === "en" && "Full information on lex.uz"}
                        {locale === "zh" && "在lex.uz上获取完整信息"}
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </ScrollReveal>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}
