"use client"

import { useEffect, useState } from "react"
import { useLocale } from "@/lib/locale-context"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ExternalLink, Eye, Search } from "lucide-react"
import Link from "next/link"
import type { Portfolio } from "@/lib/types"

export default function PortfolioPage() {
  const { locale } = useLocale()
  const [portfolios, setPortfolios] = useState<Portfolio[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  useEffect(() => {
    const fetchPortfolios = async () => {
      try {
        const response = await fetch("/api/portfolios")
        const data = await response.json()
        setPortfolios(data)
      } catch (error) {
        console.error("[v0] Error loading portfolios:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPortfolios()
  }, [])

  const filteredPortfolios = portfolios.filter((portfolio) => {
    const matchesSearch =
      searchQuery === "" ||
      portfolio[`title_${locale}` as keyof Portfolio]?.toString().toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = !selectedCategory || portfolio.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  const categories = Array.from(new Set(portfolios.map((p) => p.category)))

  const getTitle = (portfolio: Portfolio) => {
    return portfolio[`title_${locale}` as keyof Portfolio] || portfolio.title_uz
  }

  const getDescription = (portfolio: Portfolio) => {
    return portfolio[`description_${locale}` as keyof Portfolio] || portfolio.description_uz
  }

  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold">
            {locale === "uz" && "Portfolio"}
            {locale === "ru" && "Портфолио"}
            {locale === "en" && "Portfolio"}
            {locale === "zh" && "作品集"}
          </h1>
          <p className="text-xl text-muted-foreground">
            {locale === "uz" && "Mening iqtisodiy loyihalarim va ishlarim"}
            {locale === "ru" && "Мои экономические проекты и работы"}
            {locale === "en" && "My economic projects and works"}
            {locale === "zh" && "我的经济项目和作品"}
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={
                locale === "uz"
                  ? "Loyihalarni qidirish..."
                  : locale === "ru"
                    ? "Поиск проектов..."
                    : "Search projects..."
              }
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(null)}
            >
              {locale === "uz" && "Hammasi"}
              {locale === "ru" && "Все"}
              {locale === "en" && "All"}
              {locale === "zh" && "全部"}
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Portfolio Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="overflow-hidden">
                <div className="h-48 bg-muted animate-pulse" />
                <CardContent className="pt-6 space-y-3">
                  <div className="h-6 bg-muted animate-pulse rounded" />
                  <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredPortfolios.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-muted-foreground">
                {locale === "uz" && "Portfolio topilmadi"}
                {locale === "ru" && "Портфолио не найдено"}
                {locale === "en" && "No portfolios found"}
                {locale === "zh" && "未找到作品集"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPortfolios.map((portfolio) => (
              <Card key={portfolio.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
                <div className="relative h-48 bg-muted overflow-hidden">
                  {portfolio.thumbnail_url ? (
                    <img
                      src={portfolio.thumbnail_url || "/placeholder.svg"}
                      alt={getTitle(portfolio)?.toString()}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-100 to-cyan-100 dark:from-blue-900/20 dark:to-cyan-900/20">
                      <span className="text-4xl font-bold text-muted-foreground">
                        {getTitle(portfolio)?.toString().charAt(0)}
                      </span>
                    </div>
                  )}
                </div>
                <CardContent className="pt-6 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold text-lg line-clamp-2">{getTitle(portfolio)?.toString()}</h3>
                    {portfolio.project_url && (
                      <Link href={portfolio.project_url} target="_blank" rel="noopener noreferrer">
                        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </Link>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-3">{getDescription(portfolio)?.toString()}</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary">{portfolio.category}</Badge>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Eye className="h-3 w-3" />
                      {portfolio.views_count}
                    </div>
                  </div>
                  {portfolio.tags && portfolio.tags.length > 0 && (
                    <div className="flex gap-1 flex-wrap">
                      {portfolio.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
