"use client"

import { useEffect, useState } from "react"
import { useLocale } from "@/lib/locale-context"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Download, FileText, Search } from "lucide-react"
import type { Resource } from "@/lib/types"

export default function ResourcesPage() {
  const { locale } = useLocale()
  const [resources, setResources] = useState<Resource[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  useEffect(() => {
    const fetchResources = async () => {
      try {
        const response = await fetch("/api/resources")
        const data = await response.json()
        setResources(data)
      } catch (error) {
        console.error("[v0] Error loading resources:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchResources()
  }, [])

  const filteredResources = resources.filter((resource) => {
    const matchesSearch =
      searchQuery === "" ||
      resource[`title_${locale}` as keyof Resource]?.toString().toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = !selectedCategory || resource.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  const categories = Array.from(new Set(resources.map((r) => r.category)))

  const getTitle = (resource: Resource) => {
    return resource[`title_${locale}` as keyof Resource] || resource.title_uz
  }

  const getDescription = (resource: Resource) => {
    return resource[`description_${locale}` as keyof Resource] || resource.description_uz
  }

  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold">
            {locale === "uz" && "Resurslar"}
            {locale === "ru" && "Ресурсы"}
            {locale === "en" && "Resources"}
            {locale === "zh" && "资源"}
          </h1>
          <p className="text-xl text-muted-foreground">
            {locale === "uz" && "Iqtisodiy qo'llanmalar va foydali materiallar"}
            {locale === "ru" && "Экономические руководства и полезные материалы"}
            {locale === "en" && "Economic guides and useful materials"}
            {locale === "zh" && "经济指南和有用材料"}
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={
                locale === "uz"
                  ? "Resurslarni qidirish..."
                  : locale === "ru"
                    ? "Поиск ресурсов..."
                    : "Search resources..."
              }
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(null)}
            >
              {locale === "uz" && "Hammasi"}
              {locale === "ru" && "Все"}
              {locale === "en" && "All"}
              {locale === "zh" && "全部"}
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Resources List */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i}>
                <CardContent className="pt-6 space-y-3">
                  <div className="h-6 bg-muted animate-pulse rounded" />
                  <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredResources.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-muted-foreground">
                {locale === "uz" && "Resurslar topilmadi"}
                {locale === "ru" && "Ресурсы не найдены"}
                {locale === "en" && "No resources found"}
                {locale === "zh" && "未找到资源"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredResources.map((resource) => (
              <Card key={resource.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10 shrink-0">
                      <FileText className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 space-y-3">
                      <div>
                        <h3 className="font-semibold text-lg mb-1">{getTitle(resource)?.toString()}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {getDescription(resource)?.toString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="secondary">{resource.category}</Badge>
                        {resource.file_type && (
                          <Badge variant="outline" className="text-xs uppercase">
                            {resource.file_type}
                          </Badge>
                        )}
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Download className="h-3 w-3" />
                          {resource.downloads_count}
                        </div>
                      </div>
                      {resource.file_url && (
                        <Button size="sm" className="w-full" asChild>
                          <a href={resource.file_url} download>
                            <Download className="h-4 w-4 mr-2" />
                            {locale === "uz" && "Yuklab olish"}
                            {locale === "ru" && "Скачать"}
                            {locale === "en" && "Download"}
                            {locale === "zh" && "下载"}
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
