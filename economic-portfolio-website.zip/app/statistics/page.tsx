"use client"

import { useState, useEffect } from "react"
import { useLocale } from "@/lib/locale-context"
import { getTranslation } from "@/lib/i18n"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, Globe, BarChart3 } from "lucide-react"

export default function StatisticsPage() {
  const { locale } = useLocale()
  const t = getTranslation(locale)
  const [globalStats, setGlobalStats] = useState<any>(null)

  useEffect(() => {
    fetchStatistics()
  }, [])

  const fetchStatistics = async () => {
    try {
      const response = await fetch("/api/stats/global")
      const data = await response.json()
      setGlobalStats(data)
    } catch (error) {
      console.error("Error fetching statistics:", error)
      setGlobalStats(getDemoData())
    }
  }

  const getDemoData = () => ({
    world: {
      gdp: {
        value: "96.5",
        unit:
          locale === "uz"
            ? "trillion USD"
            : locale === "ru"
              ? "триллион USD"
              : locale === "en"
                ? "trillion USD"
                : "万亿美元",
        change: 2.4,
      },
      population: {
        value: "8.1",
        unit: locale === "uz" ? "milliard" : locale === "ru" ? "миллиард" : locale === "en" ? "billion" : "十亿",
        change: 0.9,
      },
      unemployment: {
        value: "5.2",
        unit: "%",
        change: -0.3,
      },
      inflation: {
        value: "3.1",
        unit: "%",
        change: -0.8,
      },
    },
    uzbekistan: {
      gdp: {
        value: "92.1",
        unit:
          locale === "uz"
            ? "milliard USD"
            : locale === "ru"
              ? "миллиард USD"
              : locale === "en"
                ? "billion USD"
                : "十亿美元",
        change: 5.2,
      },
      population: {
        value: "36.6",
        unit: locale === "uz" ? "million" : locale === "ru" ? "миллион" : locale === "en" ? "million" : "百万",
        change: 1.2,
      },
      unemployment: {
        value: "5.9",
        unit: "%",
        change: -0.4,
      },
      inflation: {
        value: "12.3",
        unit: "%",
        change: 2.1,
      },
    },
  })

  if (!globalStats) {
    setGlobalStats(getDemoData())
  }

  const pageTitle = {
    uz: "Global va Mintaqaviy Statistika",
    ru: "Глобальная и региональная статистика",
    en: "Global and Regional Statistics",
    zh: "全球和区域统计",
  }

  const statLabels = {
    uz: {
      gdp: "Gross Domestic Product (GDP)",
      population: "Aholisi",
      unemployment: "Ishsizlik darajasi",
      inflation: "Inflatsiya",
    },
    ru: {
      gdp: "Валовой внутренний продукт (ВВП)",
      population: "Население",
      unemployment: "Уровень безработицы",
      inflation: "Инфляция",
    },
    en: {
      gdp: "Gross Domestic Product (GDP)",
      population: "Population",
      unemployment: "Unemployment Rate",
      inflation: "Inflation",
    },
    zh: {
      gdp: "国内生产总值 (GDP)",
      population: "人口",
      unemployment: "失业率",
      inflation: "通货膨胀",
    },
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative py-12 md:py-20 overflow-hidden bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 dark:from-purple-950/20 dark:via-blue-950/20 dark:to-cyan-950/20">
        <div className="absolute inset-0 opacity-10">
          <svg viewBox="0 0 1200 120" className="w-full h-full">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="1200" height="120" fill="url(#grid)" />
          </svg>
        </div>

        <div className="container relative z-10">
          <ScrollReveal>
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold text-balance">
                {pageTitle[locale as keyof typeof pageTitle]}
              </h1>
              <p className="text-lg text-muted-foreground">
                {locale === "uz" && "Dunyo va O'zbekistonnning asosiy iqtisodiy ko'rsatkichlari"}
                {locale === "ru" && "Основные экономические показатели мира и Узбекистана"}
                {locale === "en" && "Key economic indicators of the world and Uzbekistan"}
                {locale === "zh" && "世界和乌兹别克斯坦的主要经济指标"}
              </p>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="flex-1 py-12 md:py-16">
        <div className="container">
          <Tabs defaultValue="world" className="space-y-8">
            <ScrollReveal>
              <TabsList className="grid w-full grid-cols-2 bg-muted">
                <TabsTrigger value="world" className="flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  {locale === "uz" && "Dunyo"}
                  {locale === "ru" && "Мир"}
                  {locale === "en" && "World"}
                  {locale === "zh" && "世界"}
                </TabsTrigger>
                <TabsTrigger value="uzbekistan" className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  {locale === "uz" && "O'zbekiston"}
                  {locale === "ru" && "Узбекистан"}
                  {locale === "en" && "Uzbekistan"}
                  {locale === "zh" && "乌兹别克斯坦"}
                </TabsTrigger>
              </TabsList>
            </ScrollReveal>

            {/* World Statistics */}
            <TabsContent value="world" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* GDP Card */}
                <ScrollReveal>
                  <Card className="relative overflow-hidden border-purple-200 dark:border-purple-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-purple-100 dark:bg-purple-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <BarChart3 className="w-4 h-4 text-purple-600" />
                        {statLabels[locale as keyof typeof statLabels].gdp}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-purple-600">
                        {globalStats?.world?.gdp?.value}
                        <span className="text-lg text-muted-foreground ml-2">{globalStats?.world?.gdp?.unit}</span>
                      </div>
                      <p
                        className={`text-sm ${(globalStats?.world?.gdp?.change || 0) > 0 ? "text-green-600" : "text-red-600"}`}
                      >
                        {(globalStats?.world?.gdp?.change || 0) > 0 ? "+" : ""}
                        {globalStats?.world?.gdp?.change}% YoY
                      </p>
                    </CardContent>
                  </Card>
                </ScrollReveal>

                {/* Population Card */}
                <ScrollReveal delay={100}>
                  <Card className="relative overflow-hidden border-blue-200 dark:border-blue-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-blue-100 dark:bg-blue-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Globe className="w-4 h-4 text-blue-600" />
                        {statLabels[locale as keyof typeof statLabels].population}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-blue-600">
                        {globalStats?.world?.population?.value}
                        <span className="text-lg text-muted-foreground ml-2">
                          {globalStats?.world?.population?.unit}
                        </span>
                      </div>
                      <p className="text-sm text-green-600">+{globalStats?.world?.population?.change}% YoY</p>
                    </CardContent>
                  </Card>
                </ScrollReveal>

                {/* Unemployment Card */}
                <ScrollReveal delay={200}>
                  <Card className="relative overflow-hidden border-cyan-200 dark:border-cyan-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-cyan-100 dark:bg-cyan-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-cyan-600" />
                        {statLabels[locale as keyof typeof statLabels].unemployment}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-cyan-600">{globalStats?.world?.unemployment?.value}%</div>
                      <p className="text-sm text-green-600">{globalStats?.world?.unemployment?.change}% change</p>
                    </CardContent>
                  </Card>
                </ScrollReveal>

                {/* Inflation Card */}
                <ScrollReveal delay={300}>
                  <Card className="relative overflow-hidden border-orange-200 dark:border-orange-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-orange-100 dark:bg-orange-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-orange-600" />
                        {statLabels[locale as keyof typeof statLabels].inflation}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-orange-600">{globalStats?.world?.inflation?.value}%</div>
                      <p className="text-sm text-red-600">{globalStats?.world?.inflation?.change}% change</p>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              </div>
            </TabsContent>

            {/* Uzbekistan Statistics */}
            <TabsContent value="uzbekistan" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* GDP Card */}
                <ScrollReveal>
                  <Card className="relative overflow-hidden border-green-200 dark:border-green-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-green-100 dark:bg-green-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <BarChart3 className="w-4 h-4 text-green-600" />
                        {statLabels[locale as keyof typeof statLabels].gdp}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-green-600">
                        {globalStats?.uzbekistan?.gdp?.value}
                        <span className="text-lg text-muted-foreground ml-2">{globalStats?.uzbekistan?.gdp?.unit}</span>
                      </div>
                      <p className="text-sm text-green-600">+{globalStats?.uzbekistan?.gdp?.change}% YoY</p>
                    </CardContent>
                  </Card>
                </ScrollReveal>

                {/* Population Card */}
                <ScrollReveal delay={100}>
                  <Card className="relative overflow-hidden border-teal-200 dark:border-teal-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-teal-100 dark:bg-teal-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Globe className="w-4 h-4 text-teal-600" />
                        {statLabels[locale as keyof typeof statLabels].population}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-teal-600">
                        {globalStats?.uzbekistan?.population?.value}
                        <span className="text-lg text-muted-foreground ml-2">
                          {globalStats?.uzbekistan?.population?.unit}
                        </span>
                      </div>
                      <p className="text-sm text-green-600">+{globalStats?.uzbekistan?.population?.change}% YoY</p>
                    </CardContent>
                  </Card>
                </ScrollReveal>

                {/* Unemployment Card */}
                <ScrollReveal delay={200}>
                  <Card className="relative overflow-hidden border-indigo-200 dark:border-indigo-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-indigo-100 dark:bg-indigo-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-indigo-600" />
                        {statLabels[locale as keyof typeof statLabels].unemployment}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-indigo-600">
                        {globalStats?.uzbekistan?.unemployment?.value}%
                      </div>
                      <p className="text-sm text-green-600">{globalStats?.uzbekistan?.unemployment?.change}% change</p>
                    </CardContent>
                  </Card>
                </ScrollReveal>

                {/* Inflation Card */}
                <ScrollReveal delay={300}>
                  <Card className="relative overflow-hidden border-rose-200 dark:border-rose-800">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-rose-100 dark:bg-rose-900/20 rounded-full -mr-8 -mt-8 blur-xl"></div>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-rose-600" />
                        {statLabels[locale as keyof typeof statLabels].inflation}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-3xl font-bold text-rose-600">
                        {globalStats?.uzbekistan?.inflation?.value}%
                      </div>
                      <p className="text-sm text-red-600">+{globalStats?.uzbekistan?.inflation?.change}% change</p>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              </div>
            </TabsContent>
          </Tabs>

          {/* Info Section */}
          <ScrollReveal delay={400}>
            <Card className="mt-12 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-slate-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle>
                  {locale === "uz" && "Ma'lumot Manbasi"}
                  {locale === "ru" && "Источник данных"}
                  {locale === "en" && "Data Source"}
                  {locale === "zh" && "数据来源"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {locale === "uz" &&
                    "Bu statistika Xalqaro Pul Fondi (IMF), Jahon Banki va O'zbekiston Respublikasi Statistika Agentligidan oligan rasmiy ma'lumotlar asosida tayyorlangan."}
                  {locale === "ru" &&
                    "Статистика составлена на основе официальных данных Международного валютного фонда (МВФ), Всемирного банка и Агентства по статистике Республики Узбекистан."}
                  {locale === "en" &&
                    "Statistics are compiled from official data from the International Monetary Fund (IMF), World Bank, and the State Statistics Agency of the Republic of Uzbekistan."}
                  {locale === "zh" &&
                    "统计数据来自国际货币基金组织(IMF)、世界银行和乌兹别克斯坦共和国统计局的官方数据。"}
                </p>
              </CardContent>
            </Card>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
