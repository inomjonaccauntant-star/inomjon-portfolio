"use client"

import { useEffect, useState } from "react"
import { useLocale } from "@/lib/locale-context"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function WelcomePage() {
  const { locale } = useLocale()
  const router = useRouter()
  const [showWelcome, setShowWelcome] = useState(true)

  const welcomeTexts = {
    uz: { greeting: "Salom!", subtitle: "Aziz mehmonimiz" },
    ru: { greeting: "Привет!", subtitle: "Уважаемый гость" },
    en: { greeting: "Hello!", subtitle: "Dear Guest" },
    zh: { greeting: "你好！", subtitle: "尊敬的客人" },
  }

  const text = welcomeTexts[locale as keyof typeof welcomeTexts] || welcomeTexts.uz

  useEffect(() => {
    const timer = setTimeout(() => {
      router.push("/")
    }, 5000)
    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="w-full h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative">
      <div className="absolute inset-0">
        {/* Animated circles in background */}
        <div className="absolute top-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-20 left-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>

        {/* Traditional uzbek pattern overlay */}
        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        ></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center space-y-8 px-4">
        {/* Main greeting */}
        <div className="space-y-4 animate-fade-in">
          <h1 className="text-6xl md:text-7xl font-bold text-white drop-shadow-lg">{text.greeting}</h1>
          <p className="text-3xl md:text-4xl text-blue-200 font-light drop-shadow-md">{text.subtitle}</p>
        </div>

        {/* Language info */}
        <div className="pt-8">
          <p className="text-lg text-gray-300 mb-4">
            {locale === "uz" && "Sayt O'zbek, Rus, Ingliz va Xitoy tillarida mavjud"}
            {locale === "ru" && "Сайт доступен на узбекском, русском, английском и китайском языках"}
            {locale === "en" && "Site available in Uzbek, Russian, English and Chinese languages"}
            {locale === "zh" && "网站提供乌兹别克语、俄语、英语和中文版本"}
          </p>
          <div className="flex justify-center gap-2 flex-wrap">
            <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">O'zbek</span>
            <span className="px-3 py-1 bg-cyan-500/20 text-cyan-300 rounded-full text-sm">Русский</span>
            <span className="px-3 py-1 bg-blue-400/20 text-blue-200 rounded-full text-sm">English</span>
            <span className="px-3 py-1 bg-slate-500/20 text-slate-300 rounded-full text-sm">中文</span>
          </div>
        </div>

        {/* CTA */}
        <div className="pt-12 space-y-4">
          <p className="text-gray-400">
            {locale === "uz" && "Saytga kirish uchun kuting yoki bosing..."}
            {locale === "ru" && "Ждите или нажмите для входа на сайт..."}
            {locale === "en" && "Wait or click to enter the site..."}
            {locale === "zh" && "等待或点击进入网站..."}
          </p>
          <Button size="lg" asChild className="bg-blue-600 hover:bg-blue-700 text-white">
            <Link href="/">
              {locale === "uz" && "Asosiy sahifaga o'tish"}
              {locale === "ru" && "Перейти на главную"}
              {locale === "en" && "Go to Homepage"}
              {locale === "zh" && "转到主页"}
            </Link>
          </Button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-cyan-500 to-blue-500 animate-pulse"></div>
    </div>
  )
}
