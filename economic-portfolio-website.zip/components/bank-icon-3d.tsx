"use client"

import { useEffect, useRef } from "react"

export function BankIcon3D() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    let rotation = 0

    const animate = () => {
      rotation += 0.5
      if (container) {
        container.style.transform = `perspective(1000px) rotateY(${rotation}deg) rotateX(${Math.sin(rotation * 0.02) * 5}deg)`
      }
      requestAnimationFrame(animate)
    }

    animate()
  }, [])

  return (
    <div className="relative w-32 h-32 mx-auto">
      <div ref={containerRef} className="w-full h-full transition-transform duration-100">
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl">
          <defs>
            <linearGradient id="bankGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: "#3B82F6", stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: "#06B6D4", stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          {/* Bank binosi */}
          <rect x="20" y="40" width="60" height="50" fill="url(#bankGradient)" rx="2" />
          {/* Ustunlar */}
          <rect x="25" y="45" width="8" height="40" fill="#ffffff" opacity="0.3" />
          <rect x="46" y="45" width="8" height="40" fill="#ffffff" opacity="0.3" />
          <rect x="67" y="45" width="8" height="40" fill="#ffffff" opacity="0.3" />
          {/* Tom */}
          <path d="M 15 40 L 50 20 L 85 40 Z" fill="url(#bankGradient)" />
          {/* Dollar belgisi */}
          <text x="50" y="70" fontSize="20" fill="#ffffff" textAnchor="middle" fontWeight="bold">
            $
          </text>
        </svg>
      </div>
    </div>
  )
}
