"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, RefreshCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLocale } from "@/lib/locale-context"
import type { CurrencyRate } from "@/lib/api/currency"

const currencyFlags: Record<string, string> = {
  USD: "🇺🇸",
  EUR: "🇪🇺",
  RUB: "🇷🇺",
  CNY: "🇨🇳",
  GBP: "🇬🇧",
}

const currencySymbols: Record<string, string> = {
  USD: "$",
  EUR: "€",
  RUB: "₽",
  CNY: "¥",
  GBP: "£",
}

export function CurrencyWidget() {
  const { locale } = useLocale()
  const [rates, setRates] = useState<CurrencyRate[]>([])
  const [loading, setLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())

  const fetchRates = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/currency")
      const data = await response.json()
      setRates(data)
      setLastUpdate(new Date())
    } catch (error) {
      console.error("[v0] Error loading currency rates:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchRates()
    const interval = setInterval(fetchRates, 30 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const getTitle = () => {
    if (locale === "uz") return "Valyuta kurslari"
    if (locale === "ru") return "Курсы валют"
    if (locale === "en") return "Exchange Rates"
    return "汇率"
  }

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-full blur-3xl" />

      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
        <CardTitle className="text-xl font-bold">{getTitle()}</CardTitle>
        <Button variant="ghost" size="icon" onClick={fetchRates} disabled={loading}>
          <RefreshCcw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </CardHeader>
      <CardContent className="relative z-10">
        <div className="space-y-3">
          {rates.map((currency, index) => (
            <div
              key={currency.code}
              className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-muted/50 to-muted/30 hover:from-muted/70 hover:to-muted/50 transition-all duration-300 transform hover:scale-[1.02] shadow-sm hover:shadow-md"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-center gap-3">
                <div className="text-3xl">{currencyFlags[currency.code]}</div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-lg">{currency.code}</span>
                    <span className="text-xl font-bold text-muted-foreground">{currencySymbols[currency.code]}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{currency.name}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="font-semibold text-lg">{currency.rate.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">UZS</div>
                </div>
                {currency.change !== 0 && (
                  <div
                    className={`flex items-center gap-1 text-sm font-semibold px-2 py-1 rounded-lg ${
                      currency.change > 0
                        ? "text-green-600 bg-green-100 dark:bg-green-900/20"
                        : "text-red-600 bg-red-100 dark:bg-red-900/20"
                    }`}
                  >
                    {currency.change > 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {Math.abs(currency.change).toFixed(2)}%
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-4 text-center">
          {locale === "uz" && `Oxirgi yangilanish: ${lastUpdate.toLocaleTimeString("uz-UZ")}`}
          {locale === "ru" && `Последнее обновление: ${lastUpdate.toLocaleTimeString("ru-RU")}`}
          {locale === "en" && `Last updated: ${lastUpdate.toLocaleTimeString("en-US")}`}
          {locale === "zh" && `最后更新: ${lastUpdate.toLocaleTimeString("zh-CN")}`}
        </p>
      </CardContent>
    </Card>
  )
}
