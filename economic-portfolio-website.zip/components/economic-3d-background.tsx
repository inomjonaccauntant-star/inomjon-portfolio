"use client"

import { useEffect, useRef } from "react"

export function Economic3DBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    // Iqtisodiy grafiklar uchun nuqtalar
    const charts: Array<{
      x: number
      y: number
      points: Array<{ x: number; y: number }>
      color: string
    }> = []

    // Valyuta belgilari
    const symbols = ["$", "€", "¥", "₽", "£"]
    const floatingSymbols: Array<{
      x: number
      y: number
      symbol: string
      opacity: number
      vy: number
    }> = []

    // Grafiklar yaratish
    for (let i = 0; i < 3; i++) {
      const points: Array<{ x: number; y: number }> = []
      const startX = Math.random() * canvas.width
      const startY = Math.random() * canvas.height

      for (let j = 0; j < 20; j++) {
        points.push({
          x: startX + j * 30,
          y: startY + Math.sin(j * 0.5) * 50 + (Math.random() - 0.5) * 20,
        })
      }

      charts.push({
        x: startX,
        y: startY,
        points,
        color: i % 2 === 0 ? "rgba(59, 130, 246, 0.15)" : "rgba(6, 182, 212, 0.15)",
      })
    }

    // Suzuvchi valyuta belgilari
    for (let i = 0; i < 15; i++) {
      floatingSymbols.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        opacity: Math.random() * 0.1 + 0.05,
        vy: (Math.random() - 0.5) * 0.3,
      })
    }

    function animate() {
      if (!ctx || !canvas) return

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Grafiklarni chizish
      charts.forEach((chart) => {
        ctx.beginPath()
        ctx.strokeStyle = chart.color
        ctx.lineWidth = 2

        chart.points.forEach((point, index) => {
          if (index === 0) {
            ctx.moveTo(point.x, point.y)
          } else {
            ctx.lineTo(point.x, point.y)
          }
        })

        ctx.stroke()

        // Nuqtalarni chizish
        chart.points.forEach((point) => {
          ctx.beginPath()
          ctx.arc(point.x, point.y, 3, 0, Math.PI * 2)
          ctx.fillStyle = chart.color
          ctx.fill()
        })

        // Grafikni animatsiya qilish
        chart.points.forEach((point, index) => {
          point.y += Math.sin(Date.now() * 0.001 + index) * 0.2
        })
      })

      // Valyuta belgilarini chizish
      floatingSymbols.forEach((symbol) => {
        ctx.font = "24px monospace"
        ctx.fillStyle = `rgba(59, 130, 246, ${symbol.opacity})`
        ctx.fillText(symbol.symbol, symbol.x, symbol.y)

        // Animatsiya
        symbol.y += symbol.vy
        if (symbol.y < 0 || symbol.y > canvas.height) {
          symbol.vy *= -1
        }
      })

      requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none opacity-20" />
}
