"use client"

import { useEffect, useState } from "react"
import { Clock } from "lucide-react"

export function FargonaClockWidget() {
  const [time, setTime] = useState<string>("")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const updateTime = () => {
      const now = new Date()
      const fargonaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Tashkent" }))
      setTime(
        fargonaTime.toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false,
        }),
      )
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  if (!mounted) return null

  return (
    <div className="flex items-center gap-3 px-4 py-2 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-lg border border-blue-500/20">
      <Clock className="w-5 h-5 text-blue-500" />
      <div>
        <p className="text-xs text-gray-500 dark:text-gray-400">Farg'ona Vaqti</p>
        <p className="text-lg font-mono font-bold text-blue-600 dark:text-blue-400">{time || "00:00:00"}</p>
      </div>
    </div>
  )
}
