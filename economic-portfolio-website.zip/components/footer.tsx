"use client"

import { useLocale } from "@/lib/locale-context"
import { getTranslation } from "@/lib/i18n"
import { Mail, Send, Instagram } from "lucide-react"

export function Footer() {
  const { locale } = useLocale()
  const t = getTranslation(locale)

  return (
    <footer className="border-t bg-background relative overflow-hidden">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-t from-blue-500/5 to-transparent rounded-full blur-3xl" />

      <div className="container py-8 md:py-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center">
                <span className="text-white font-bold text-sm">IO</span>
              </div>
              <span className="font-bold text-lg">Inomjon.uz</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {locale === "uz" && "Buxgalter Iqtisodchi - Professional iqtisodiy tahlil va maslahat xizmatlari"}
              {locale === "ru" && "Бухгалтер-экономист - Профессиональный экономический анализ и консалтинг"}
              {locale === "en" && "Accountant-Economist - Professional economic analysis and consulting services"}
              {locale === "zh" && "会计经济学家 - 专业经济分析和咨询服务"}
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold">
              {locale === "uz" && "Bo'limlar"}
              {locale === "ru" && "Разделы"}
              {locale === "en" && "Sections"}
              {locale === "zh" && "栏目"}
            </h3>
            <nav className="flex flex-col space-y-2 text-sm text-muted-foreground">
              <a href="/portfolio" className="hover:text-primary transition-colors">
                {t.nav.portfolio}
              </a>
              <a href="/blog" className="hover:text-primary transition-colors">
                {t.nav.blog}
              </a>
              <a href="/resources" className="hover:text-primary transition-colors">
                {t.nav.resources}
              </a>
              <a href="/about" className="hover:text-primary transition-colors">
                {t.nav.about}
              </a>
            </nav>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold">
              {locale === "uz" && "Aloqa"}
              {locale === "ru" && "Контакты"}
              {locale === "en" && "Contact"}
              {locale === "zh" && "联系"}
            </h3>
            <div className="flex flex-col space-y-2 text-sm">
              <a
                href="mailto:Inomjonaccauntant@gmail.com"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
              >
                <Mail className="h-4 w-4" />
                Inomjonaccauntant@gmail.com
              </a>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold">
              {locale === "uz" && "Ijtimoiy tarmoqlar"}
              {locale === "ru" && "Социальные сети"}
              {locale === "en" && "Social Media"}
              {locale === "zh" && "社交媒体"}
            </h3>
            <div className="flex flex-col gap-3">
              <a
                href="https://t.me/inomjon_olimov"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                <Send className="h-4 w-4" />
                @inomjon_olimov
              </a>
              <a
                href="https://instagram.com/inomjon_accountant"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                <Instagram className="h-4 w-4" />
                @inomjon_accountant
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Inomjon.uz - Olimov Inomjon. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
