"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Globe, MapPin } from "lucide-react"
import { useLocale } from "@/lib/locale-context"
import type { NewsArticle } from "@/lib/types"

const SAMPLE_NEWS: NewsArticle[] = [
  {
    id: "1",
    title_uz: "O'zbekiston IMFC sammitida ishtirok etdi",
    title_ru: "Узбекистан участвует в саммите ИМВФ",
    title_en: "Uzbekistan participates in IMF summit",
    title_zh: "乌兹别克斯坦参加国际货币基金组织峰会",
    content_uz:
      "Birlashgan Millatlar Tashkil Otasining mal-moliya bo'yicha sammitida O'zbekiston o'z iqtisodiy islohatlari haqida ma'lumot berdi...",
    content_ru: "На саммите ООН по финансам Узбекистан представил информацию о своих экономических реформах...",
    content_en: "At the UN Financial Summit, Uzbekistan presented information about its economic reforms...",
    content_zh: "在联合国财务峰会上，乌兹别克斯坦介绍了其经济改革的信息...",
    source: "UzA News",
    source_url: "https://uza.uz",
    category: "iqtisodiy",
    region: "regional",
    ai_generated: false,
    published_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
  },
  {
    id: "2",
    title_uz: "Jahon bankir hamkorligida yangi tendentsiyalar",
    title_ru: "Новые тенденции в мировом банковском сотрудничестве",
    title_en: "New trends in global banking cooperation",
    title_zh: "全球银行合作的新趋势",
    content_uz:
      "Jahon iqtisodiyoti bozorida yangi tendentsiyalar paydo bo'lmoqda. Kripto-valyuta va raqamli pul markazi kengayib bormoqda...",
    content_ru:
      "На мировом экономическом рынке появляются новые тенденции. Центр криптовалюты и цифровых денег расширяется...",
    content_en:
      "New trends are emerging in the global economic market. The center of cryptocurrency and digital money is expanding...",
    content_zh: "全球经济市场出现了新趋势。加密货币和数字货币中心正在扩大...",
    source: "Bloomberg",
    source_url: "https://bloomberg.com",
    category: "moliya",
    region: "global",
    ai_generated: false,
    published_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
  },
  {
    id: "3",
    title_uz: "Tashkent Xalqaro Finans Markazi rivojlanib bormoqda",
    title_ru: "Таможенный финансовый центр Ташкента развивается",
    title_en: "Tashkent International Financial Center is developing",
    title_zh: "塔什干国际金融中心正在发展",
    content_uz:
      "Tashkent Xalqaro Finans Markazi 2024 yilda yangi yo'nalishlarga bormoqda. Shuning uchun multinational kompaniyalar bilan hamkorlik...",
    content_ru: "Таможенный финансовый центр Ташкента движется в новые направления в 2024 году...",
    content_en: "The Tashkent International Financial Center is moving in new directions in 2024...",
    content_zh: "塔什干国际金融中心在2024年朝着新方向发展...",
    source: "Iqtisod.uz",
    source_url: "https://iqtisod.uz",
    category: "finans",
    region: "regional",
    ai_generated: false,
    published_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
  },
]

export function GoogleNewsDigest() {
  const { locale } = useLocale()
  const [news, setNews] = useState<NewsArticle[]>(SAMPLE_NEWS)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await fetch("/api/news")
        const data = await response.json()
        if (Array.isArray(data) && data.length > 0) {
          setNews(data.slice(0, 6))
        } else {
          setNews(SAMPLE_NEWS)
        }
      } catch (error) {
        console.error("[v0] Error loading news:", error)
        setNews(SAMPLE_NEWS)
      } finally {
        setLoading(false)
      }
    }
    fetchNews()
  }, [])

  const getTitle = (article: NewsArticle) => {
    if (locale === "uz") return article.title_uz
    if (locale === "ru") return article.title_ru
    if (locale === "en") return article.title_en
    return article.title_zh
  }

  const getContent = (article: NewsArticle) => {
    const contentMap: Record<string, string | undefined> = {
      uz: article.content_uz,
      ru: article.content_ru,
      en: article.content_en,
      zh: article.content_zh,
    }
    const content = contentMap[locale] || article.content_uz
    return content.length > 140 ? content.substring(0, 140) + "..." : content
  }

  const getPageTitle = () => {
    if (locale === "uz") return "Google Yangiliklari va Digest"
    if (locale === "ru") return "Google Новости и Дайджест"
    if (locale === "en") return "Google News & Digest"
    return "谷歌新闻和摘要"
  }

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-500/10 to-indigo-500/10 rounded-full blur-3xl" />

      <CardHeader className="relative z-10 pb-4">
        <CardTitle className="text-2xl font-bold flex items-center gap-2">
          <span className="text-2xl">📰</span>
          {getPageTitle()}
        </CardTitle>
        <p className="text-sm text-muted-foreground mt-2">
          {locale === "uz" && "Google va ochiq manbalardan yig'ilgan iqtisodiy yangiliklar"}
          {locale === "ru" && "Экономические новости, собранные из Google и открытых источников"}
          {locale === "en" && "Economic news compiled from Google and open sources"}
          {locale === "zh" && "从谷歌和开放来源汇编的经济新闻"}
        </p>
      </CardHeader>

      <CardContent className="relative z-10">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 bg-muted/50 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {news.map((article, index) => (
              <div
                key={article.id}
                className="p-4 rounded-xl bg-gradient-to-r from-muted/30 to-muted/10 hover:from-muted/50 hover:to-muted/30 transition-all duration-300 border border-border/50 hover:border-primary/30 hover:shadow-lg transform hover:scale-[1.01]"
                style={{ animationDelay: `${index * 75}ms` }}
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm leading-snug hover:text-primary transition-colors line-clamp-2">
                        {getTitle(article)}
                      </h3>
                    </div>
                    {article.source_url && (
                      <a
                        href={article.source_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="shrink-0 text-muted-foreground hover:text-primary transition-colors"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    )}
                  </div>

                  <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">{getContent(article)}</p>

                  <div className="flex items-center gap-2 flex-wrap pt-2">
                    <Badge variant="secondary" className="text-xs">
                      {article.source}
                    </Badge>
                    {article.region === "global" ? (
                      <Badge variant="outline" className="text-xs flex items-center gap-1">
                        <Globe className="h-3 w-3" />
                        {locale === "uz" ? "Jahon" : locale === "ru" ? "Мир" : locale === "zh" ? "世界" : "Global"}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-xs flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {locale === "uz"
                          ? "Mintaqa"
                          : locale === "ru"
                            ? "Регион"
                            : locale === "zh"
                              ? "地区"
                              : "Regional"}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
