"use client"

import Link from "next/link"
import { useLocale } from "@/lib/locale-context"
import { getTranslation } from "@/lib/i18n"
import { LanguageSwitcher } from "./language-switcher"
import { ThemeToggle } from "./theme-toggle"
import { Button } from "@/components/ui/button"
import { Menu } from "lucide-react"
import { useState } from "react"
import { FargonaClockWidget } from "./fargona-clock"
import { InteractiveNavLink } from "./interactive-nav-link"

export function Header() {
  const { locale } = useLocale()
  const t = getTranslation(locale)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center space-x-2 group hover:opacity-80 transition-opacity">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center group-hover:shadow-lg group-hover:shadow-blue-500/50 transition-all duration-300">
            <span className="text-white font-bold text-sm">IO</span>
          </div>
          <span className="font-bold text-lg group-hover:text-primary transition-colors duration-300">Inomjon.uz</span>
        </Link>

        <nav className="hidden lg:flex items-center gap-6">
          <InteractiveNavLink href="/">{t.nav.home}</InteractiveNavLink>
          <InteractiveNavLink href="/about">{t.nav.about}</InteractiveNavLink>
          <InteractiveNavLink href="/portfolio">{t.nav.portfolio}</InteractiveNavLink>
          <InteractiveNavLink href="/blog">{t.nav.blog}</InteractiveNavLink>
          <InteractiveNavLink href="/resources">{t.nav.resources}</InteractiveNavLink>
          <InteractiveNavLink href="/laws">{t.nav.laws}</InteractiveNavLink>
          <InteractiveNavLink href="/contact">{t.nav.contact}</InteractiveNavLink>
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden xl:block">
            <FargonaClockWidget />
          </div>
          <ThemeToggle />
          <LanguageSwitcher />
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden hover:bg-primary/10 transition-colors duration-300"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-card/50 backdrop-blur animate-in fade-in slide-in-from-top-2">
          <nav className="container flex flex-col gap-4 py-4">
            <InteractiveNavLink href="/" onClick={() => setMobileMenuOpen(false)}>
              {t.nav.home}
            </InteractiveNavLink>
            <InteractiveNavLink href="/about" onClick={() => setMobileMenuOpen(false)}>
              {t.nav.about}
            </InteractiveNavLink>
            <InteractiveNavLink href="/portfolio" onClick={() => setMobileMenuOpen(false)}>
              {t.nav.portfolio}
            </InteractiveNavLink>
            <InteractiveNavLink href="/blog" onClick={() => setMobileMenuOpen(false)}>
              {t.nav.blog}
            </InteractiveNavLink>
            <InteractiveNavLink href="/resources" onClick={() => setMobileMenuOpen(false)}>
              {t.nav.resources}
            </InteractiveNavLink>
            <InteractiveNavLink href="/laws" onClick={() => setMobileMenuOpen(false)}>
              {t.nav.laws}
            </InteractiveNavLink>
            <InteractiveNavLink href="/contact" onClick={() => setMobileMenuOpen(false)}>
              {t.nav.contact}
            </InteractiveNavLink>
          </nav>
        </div>
      )}
    </header>
  )
}
