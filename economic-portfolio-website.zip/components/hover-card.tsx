"use client"

import type { ReactNode } from "react"

interface HoverCardProps {
  children: ReactNode
  className?: string
}

export function HoverCard({ children, className = "" }: HoverCardProps) {
  return (
    <div
      className={`card-hover relative overflow-hidden rounded-lg border border-transparent bg-card p-4 shadow-sm hover:border-primary/50 hover:shadow-xl transition-all duration-300 ${className}`}
    >
      <div className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity duration-300 bg-gradient-to-br from-primary/5 to-secondary/5 pointer-events-none"></div>
      <div className="relative z-10">{children}</div>
    </div>
  )
}
