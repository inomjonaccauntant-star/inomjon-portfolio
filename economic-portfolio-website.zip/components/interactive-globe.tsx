"use client"

import { useEffect, useRef } from "react"

export function InteractiveGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const size = 300
    canvas.width = size
    canvas.height = size

    let rotation = 0

    const drawGlobe = () => {
      if (!ctx) return

      ctx.clearRect(0, 0, size, size)

      const centerX = size / 2
      const centerY = size / 2
      const radius = size / 2 - 20

      // Draw outer circle
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(59, 130, 246, 0.3)"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw meridians
      for (let i = 0; i < 8; i++) {
        const angle = (i * Math.PI) / 4 + rotation
        ctx.beginPath()
        ctx.ellipse(centerX, centerY, radius * Math.abs(Math.cos(angle)), radius, 0, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(59, 130, 246, 0.2)"
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Draw parallels
      for (let i = 1; i < 4; i++) {
        const y = centerY - radius + (i * radius * 2) / 4
        const width = Math.sqrt(radius * radius - Math.pow(y - centerY, 2)) * 2

        ctx.beginPath()
        ctx.ellipse(centerX, y, width / 2, 10, 0, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(59, 130, 246, 0.2)"
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Draw data points
      for (let i = 0; i < 12; i++) {
        const angle = (i * Math.PI * 2) / 12 + rotation
        const distance = radius * 0.8
        const x = centerX + Math.cos(angle) * distance
        const y = centerY + Math.sin(angle) * distance * 0.5

        ctx.beginPath()
        ctx.arc(x, y, 4, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(59, 130, 246, 0.8)"
        ctx.fill()
      }

      rotation += 0.005
      requestAnimationFrame(drawGlobe)
    }

    drawGlobe()
  }, [])

  return (
    <div className="flex items-center justify-center">
      <canvas ref={canvasRef} className="max-w-full h-auto" />
    </div>
  )
}
