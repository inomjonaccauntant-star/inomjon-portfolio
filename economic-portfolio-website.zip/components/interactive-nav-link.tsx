"use client"

import Link from "next/link"
import type { ReactNode } from "react"

interface InteractiveNavLinkProps {
  href: string
  children: ReactNode
  onClick?: () => void
}

export function InteractiveNavLink({ href, children, onClick }: InteractiveNavLinkProps) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className="nav-link-hover text-sm font-medium transition-colors hover:text-primary relative group"
    >
      <span className="relative z-10">{children}</span>
      <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 via-cyan-500 to-blue-500 group-hover:w-full transition-all duration-300"></span>
    </Link>
  )
}
