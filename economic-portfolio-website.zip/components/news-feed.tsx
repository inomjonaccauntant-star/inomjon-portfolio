"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Newspaper, RefreshCw, TrendingUp, Globe } from "lucide-react"
import { useLocale } from "@/lib/locale-context"
import type { NewsArticle } from "@/lib/types"

export function NewsFeed() {
  const { locale } = useLocale()
  const [news, setNews] = useState<NewsArticle[]>([])
  const [loading, setLoading] = useState(true)

  const fetchNews = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/news")
      if (!response.ok) {
        console.error("[v0] News fetch failed:", response.status)
        setNews([])
        return
      }
      const data = await response.json()
      if (Array.isArray(data)) {
        setNews(data.slice(0, 8))
      } else {
        console.error("[v0] News data is not an array:", data)
        setNews([])
      }
    } catch (error) {
      console.error("[v0] Error loading news:", error)
      setNews([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchNews()
    const interval = setInterval(fetchNews, 30 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const getTitle = (article: NewsArticle) => {
    return article[`title_${locale}` as keyof NewsArticle] || article.title_uz
  }

  const getContent = (article: NewsArticle) => {
    const content = article[`content_${locale}` as keyof NewsArticle] || article.content_uz
    const contentStr = content?.toString() || ""
    return contentStr.length > 120 ? contentStr.substring(0, 120) + "..." : contentStr
  }

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl" />

      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 relative z-10">
        <CardTitle className="text-2xl font-bold flex items-center gap-2">
          <Newspaper className="h-6 w-6 text-primary" />
          {locale === "uz" && "So'nggi Yangiliklar"}
          {locale === "ru" && "Последние новости"}
          {locale === "en" && "Latest News"}
          {locale === "zh" && "最新新闻"}
        </CardTitle>
        <Button variant="ghost" size="icon" onClick={fetchNews} disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </CardHeader>
      <CardContent className="relative z-10">
        {loading ? (
          <div className="grid md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-2 p-4 rounded-lg bg-muted/50">
                <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
                <div className="h-3 bg-muted animate-pulse rounded w-full" />
                <div className="h-3 bg-muted animate-pulse rounded w-5/6" />
              </div>
            ))}
          </div>
        ) : news.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            {locale === "uz" && "Yangiliklar topilmadi"}
            {locale === "ru" && "Новости не найдены"}
            {locale === "en" && "No news found"}
            {locale === "zh" && "未找到新闻"}
          </p>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {news.map((article, index) => (
              <div
                key={article.id}
                className="p-4 rounded-xl bg-gradient-to-br from-muted/30 to-muted/10 hover:from-muted/50 hover:to-muted/30 transition-all duration-300 border border-border/50 hover:border-primary/30 hover:shadow-lg transform hover:scale-[1.02]"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <div className="p-2 rounded-lg bg-primary/10 shrink-0">
                      {article.region === "global" ? (
                        <Globe className="h-4 w-4 text-primary" />
                      ) : (
                        <TrendingUp className="h-4 w-4 text-primary" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm leading-tight hover:text-primary transition-colors line-clamp-2">
                        {getTitle(article)?.toString()}
                      </h3>
                    </div>
                    {article.source_url && (
                      <a href={article.source_url} target="_blank" rel="noopener noreferrer" className="shrink-0 mt-1">
                        <ExternalLink className="h-4 w-4 text-muted-foreground hover:text-primary" />
                      </a>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{getContent(article)}</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary" className="text-xs">
                      {article.category}
                    </Badge>
                    {article.region && (
                      <Badge variant="outline" className="text-xs">
                        {article.region === "global"
                          ? locale === "uz"
                            ? "Jahon"
                            : locale === "ru"
                              ? "Мир"
                              : locale === "zh"
                                ? "世界"
                                : "Global"
                          : locale === "uz"
                            ? "Mintaqa"
                            : locale === "ru"
                              ? "Регион"
                              : locale === "zh"
                                ? "地区"
                                : "Regional"}
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground ml-auto">
                      {article.published_at
                        ? new Date(article.published_at).toLocaleDateString(locale, {
                            month: "short",
                            day: "numeric",
                          })
                        : new Date(article.created_at).toLocaleDateString(locale, { month: "short", day: "numeric" })}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
