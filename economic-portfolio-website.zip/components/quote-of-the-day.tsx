"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { QuoteIcon, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLocale } from "@/lib/locale-context"
import type { Quote } from "@/lib/types"

export function QuoteOfTheDay() {
  const { locale } = useLocale()
  const [quote, setQuote] = useState<Quote | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchQuote = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/quotes/random")
      const data = await response.json()
      setQuote(data)
    } catch (error) {
      console.error("[v0] Error loading quote:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchQuote()
  }, [])

  const getAuthor = (quote: Quote) => {
    return quote[`author_${locale}` as keyof Quote] || quote.author_uz
  }

  const getText = (quote: Quote) => {
    return quote[`text_${locale}` as keyof Quote] || quote.text_uz
  }

  if (loading || !quote) {
    return (
      <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20">
        <CardContent className="pt-6 pb-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-pulse text-muted-foreground">
              {locale === "uz" && "Yuklanmoqda..."}
              {locale === "ru" && "Загрузка..."}
              {locale === "en" && "Loading..."}
              {locale === "zh" && "加载中..."}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20 border-none">
      <CardContent className="pt-8 pb-8">
        <div className="flex items-start gap-4">
          <QuoteIcon className="h-8 w-8 text-primary shrink-0 mt-1" />
          <div className="flex-1 space-y-4">
            <blockquote className="text-lg md:text-xl font-medium italic leading-relaxed">
              "{getText(quote)?.toString()}"
            </blockquote>
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-muted-foreground">— {getAuthor(quote)?.toString()}</p>
              <Button variant="ghost" size="icon" onClick={fetchQuote}>
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
