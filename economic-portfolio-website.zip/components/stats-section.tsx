"use client"

import { Card, CardContent } from "@/components/ui/card"
import { AnimatedCounter } from "./animated-counter"
import { ScrollReveal } from "./scroll-reveal"
import { FloatingCard } from "./floating-card"
import { useLocale } from "@/lib/locale-context"

export function StatsSection() {
  const { locale } = useLocale()

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <ScrollReveal>
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {locale === "uz" && "Statistika"}
              {locale === "ru" && "Статистика"}
              {locale === "en" && "Statistics"}
              {locale === "zh" && "统计"}
            </h2>
            <p className="text-muted-foreground">
              {locale === "uz" && "Platformamizning yutuqlari"}
              {locale === "ru" && "Достижения нашей платформы"}
              {locale === "en" && "Our platform achievements"}
              {locale === "zh" && "我们平台的成就"}
            </p>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ScrollReveal delay={100}>
            <FloatingCard>
              <Card className="text-center border-2 hover:border-primary transition-colors">
                <CardContent className="pt-8 pb-8">
                  <div className="text-5xl font-bold text-primary mb-2">
                    <AnimatedCounter end={1250} suffix="+" />
                  </div>
                  <p className="text-muted-foreground">
                    {locale === "uz" && "Maqolalar"}
                    {locale === "ru" && "Статьи"}
                    {locale === "en" && "Articles"}
                    {locale === "zh" && "文章"}
                  </p>
                </CardContent>
              </Card>
            </FloatingCard>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <FloatingCard>
              <Card className="text-center border-2 hover:border-primary transition-colors">
                <CardContent className="pt-8 pb-8">
                  <div className="text-5xl font-bold text-primary mb-2">
                    <AnimatedCounter end={85} suffix="K+" />
                  </div>
                  <p className="text-muted-foreground">
                    {locale === "uz" && "O'quvchilar"}
                    {locale === "ru" && "Читатели"}
                    {locale === "en" && "Readers"}
                    {locale === "zh" && "读者"}
                  </p>
                </CardContent>
              </Card>
            </FloatingCard>
          </ScrollReveal>

          <ScrollReveal delay={300}>
            <FloatingCard>
              <Card className="text-center border-2 hover:border-primary transition-colors">
                <CardContent className="pt-8 pb-8">
                  <div className="text-5xl font-bold text-primary mb-2">
                    <AnimatedCounter end={320} suffix="+" />
                  </div>
                  <p className="text-muted-foreground">
                    {locale === "uz" && "Loyihalar"}
                    {locale === "ru" && "Проектов"}
                    {locale === "en" && "Projects"}
                    {locale === "zh" && "项目"}
                  </p>
                </CardContent>
              </Card>
            </FloatingCard>
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
