"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLocale } from "@/lib/locale-context"
import type { StockPrice } from "@/lib/types"

export function StockMarketWidget() {
  const { locale } = useLocale()
  const [stocks, setStocks] = useState<StockPrice[]>([])
  const [loading, setLoading] = useState(true)

  const fetchStocks = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/stocks")
      const data = await response.json()
      setStocks(data)
    } catch (error) {
      console.error("[v0] Error loading stocks:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStocks()
    const interval = setInterval(fetchStocks, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const getName = (stock: StockPrice) => {
    if (locale === "uz") return stock.name_uz
    if (locale === "ru") return stock.name_ru
    if (locale === "en") return stock.name_en
    return stock.name_zh
  }

  const getTitle = () => {
    if (locale === "uz") return "Birja Narxlari"
    if (locale === "ru") return "Цены на рынке"
    if (locale === "en") return "Market Prices"
    return "市场价格"
  }

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-amber-500/10 to-orange-500/10 rounded-full blur-3xl" />

      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 relative z-10">
        <CardTitle className="text-2xl font-bold flex items-center gap-2">
          <span className="text-2xl">📈</span>
          {getTitle()}
        </CardTitle>
        <Button variant="ghost" size="icon" onClick={fetchStocks} disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </CardHeader>

      <CardContent className="relative z-10">
        {loading ? (
          <div className="grid md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-24 bg-muted/50 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {stocks.map((stock, index) => (
              <div
                key={stock.id}
                className="p-4 rounded-xl bg-gradient-to-br from-muted/40 to-muted/20 hover:from-muted/60 hover:to-muted/40 transition-all duration-300 border border-border/50 hover:border-primary/30 hover:shadow-lg"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{stock.icon}</span>
                      <div>
                        <p className="font-semibold">{stock.symbol}</p>
                        <p className="text-xs text-muted-foreground">{getName(stock)}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-end justify-between pt-2 border-t border-border/30">
                    <div>
                      <p className="text-2xl font-bold">{stock.price.toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">{stock.currency}</p>
                    </div>

                    <div
                      className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
                        stock.change_percent >= 0
                          ? "text-green-600 bg-green-100 dark:bg-green-900/30"
                          : "text-red-600 bg-red-100 dark:bg-red-900/30"
                      }`}
                    >
                      {stock.change_percent >= 0 ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      <span className="text-sm font-semibold">{Math.abs(stock.change_percent).toFixed(2)}%</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
