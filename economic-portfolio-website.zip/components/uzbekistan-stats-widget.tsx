"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown } from "lucide-react"
import { useLocale } from "@/lib/locale-context"
import type { EconomicStat } from "@/lib/types"

export function UzbekistanStatsWidget() {
  const { locale } = useLocale()
  const [stats, setStats] = useState<EconomicStat[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch("/api/stats/uzbekistan")
        const data = await response.json()
        setStats(data)
      } catch (error) {
        console.error("[v0] Error loading stats:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchStats()
  }, [])

  const getTitle = (stat: EconomicStat) => {
    if (locale === "uz") return stat.title_uz
    if (locale === "ru") return stat.title_ru
    if (locale === "en") return stat.title_en
    return stat.title_zh
  }

  const getUnit = (stat: EconomicStat) => {
    if (locale === "uz") return stat.unit_uz
    if (locale === "ru") return stat.unit_ru
    if (locale === "en") return stat.unit_en
    return stat.unit_zh
  }

  const getPageTitle = () => {
    if (locale === "uz") return "O'zbekiston Iqtisodiyoti"
    if (locale === "ru") return "Экономика Узбекистана"
    if (locale === "en") return "Uzbekistan Economy"
    return "乌兹别克斯坦经济"
  }

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 rounded-full blur-3xl" />

      <CardHeader className="pb-4 relative z-10">
        <CardTitle className="text-2xl font-bold flex items-center gap-2">
          <span className="text-2xl">🏛️</span>
          {getPageTitle()}
        </CardTitle>
      </CardHeader>

      <CardContent className="relative z-10">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {stats.map((stat) => (
              <div
                key={stat.id}
                className="p-4 rounded-xl bg-gradient-to-r from-muted/40 to-muted/20 hover:from-muted/60 hover:to-muted/40 transition-all duration-300 border border-border/50 hover:border-primary/30 hover:shadow-lg"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-2xl">{stat.icon}</span>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{getTitle(stat)}</p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-xl font-bold">{stat.value.toLocaleString()}</span>
                        <span className="text-xs text-muted-foreground">{getUnit(stat)}</span>
                      </div>
                    </div>
                  </div>

                  <div
                    className={`flex items-center gap-1 px-3 py-1 rounded-lg ${
                      stat.growth >= 0
                        ? "text-green-600 bg-green-100 dark:bg-green-900/30"
                        : "text-red-600 bg-red-100 dark:bg-red-900/30"
                    }`}
                  >
                    {stat.growth >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    <span className="text-sm font-semibold">{Math.abs(stat.growth).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
