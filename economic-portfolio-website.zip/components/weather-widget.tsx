"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Droplets, Wind, Sunrise, Sunset, Eye } from "lucide-react"
import { useLocale } from "@/lib/locale-context"
import type { WeatherData } from "@/lib/api/weather"

export function WeatherWidget() {
  const { locale } = useLocale()
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await fetch("/api/weather")
        const data = await response.json()
        setWeather(data)
      } catch (error) {
        console.error("[v0] Error loading weather:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchWeather()
    const interval = setInterval(fetchWeather, 15 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const getAirQualityLevel = (aqi: number) => {
    if (aqi <= 50) return { label: "Yaxshi", color: "text-green-600", bgColor: "bg-green-100 dark:bg-green-900/20" }
    if (aqi <= 100)
      return { label: "O'rtacha", color: "text-yellow-600", bgColor: "bg-yellow-100 dark:bg-yellow-900/20" }
    if (aqi <= 150)
      return { label: "Sog'liq uchun xavfli", color: "text-orange-600", bgColor: "bg-orange-100 dark:bg-orange-900/20" }
    return { label: "Xavfli", color: "text-red-600", bgColor: "bg-red-100 dark:bg-red-900/20" }
  }

  const getTitle = () => {
    if (locale === "uz") return "Ob-havo (Farg'ona)"
    if (locale === "ru") return "Погода (Фергана)"
    if (locale === "en") return "Weather (Fergana)"
    return "天气（费尔干纳）"
  }

  if (loading || !weather) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center h-40">
            <div className="animate-pulse text-muted-foreground">
              {locale === "uz" && "Yuklanmoqda..."}
              {locale === "ru" && "Загрузка..."}
              {locale === "en" && "Loading..."}
              {locale === "zh" && "加载中..."}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const airQualityIndex = 45
  const aqiData = getAirQualityLevel(airQualityIndex)

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 left-0 w-64 h-64 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-full blur-3xl" />

      <CardHeader className="relative z-10">
        <CardTitle className="text-xl font-bold">{getTitle()}</CardTitle>
        <p className="text-sm text-muted-foreground">
          {weather.city}, {weather.country}
        </p>
      </CardHeader>
      <CardContent className="relative z-10">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="text-6xl font-bold bg-gradient-to-br from-blue-600 to-cyan-500 bg-clip-text text-transparent">
                {weather.temperature}°
              </div>
              <div className="space-y-1">
                <p className="text-lg font-semibold capitalize">{weather.description}</p>
                <p className="text-sm text-muted-foreground">
                  {locale === "uz" && `Seziladi: ${weather.feelsLike}°C`}
                  {locale === "ru" && `Ощущается: ${weather.feelsLike}°C`}
                  {locale === "en" && `Feels like: ${weather.feelsLike}°C`}
                  {locale === "zh" && `体感: ${weather.feelsLike}°C`}
                </p>
              </div>
            </div>
          </div>

          <div className={`p-4 rounded-xl ${aqiData.bgColor}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className={`h-5 w-5 ${aqiData.color}`} />
                <div>
                  <p className="text-xs text-muted-foreground">
                    {locale === "uz" && "Havo tozaligi indeksi"}
                    {locale === "ru" && "Индекс качества воздуха"}
                    {locale === "en" && "Air Quality Index"}
                    {locale === "zh" && "空气质量指数"}
                  </p>
                  <p className={`text-sm font-semibold ${aqiData.color}`}>{aqiData.label}</p>
                </div>
              </div>
              <div className={`text-2xl font-bold ${aqiData.color}`}>{airQualityIndex}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div className="flex items-center gap-2">
              <Droplets className="h-4 w-4 text-blue-500" />
              <div>
                <p className="text-xs text-muted-foreground">
                  {locale === "uz" && "Namlik"}
                  {locale === "ru" && "Влажность"}
                  {locale === "en" && "Humidity"}
                  {locale === "zh" && "湿度"}
                </p>
                <p className="text-sm font-semibold">{weather.humidity}%</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Wind className="h-4 w-4 text-cyan-500" />
              <div>
                <p className="text-xs text-muted-foreground">
                  {locale === "uz" && "Shamol"}
                  {locale === "ru" && "Ветер"}
                  {locale === "en" && "Wind"}
                  {locale === "zh" && "风速"}
                </p>
                <p className="text-sm font-semibold">{weather.windSpeed} km/h</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Sunrise className="h-4 w-4 text-orange-500" />
              <div>
                <p className="text-xs text-muted-foreground">
                  {locale === "uz" && "Quyosh chiqishi"}
                  {locale === "ru" && "Восход"}
                  {locale === "en" && "Sunrise"}
                  {locale === "zh" && "日出"}
                </p>
                <p className="text-sm font-semibold">{weather.sunrise}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Sunset className="h-4 w-4 text-red-500" />
              <div>
                <p className="text-xs text-muted-foreground">
                  {locale === "uz" && "Quyosh botishi"}
                  {locale === "ru" && "Закат"}
                  {locale === "en" && "Sunset"}
                  {locale === "zh" && "日落"}
                </p>
                <p className="text-sm font-semibold">{weather.sunset}</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
