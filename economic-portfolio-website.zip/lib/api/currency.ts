export interface CurrencyRate {
  code: string
  name: string
  rate: number
  change: number
  lastUpdated: string
}

export async function getCurrencyRates(): Promise<CurrencyRate[]> {
  try {
    // Using CBU API for Uzbekistan currency rates
    const response = await fetch("https://cbu.uz/ru/arkhiv-kursov-valyut/json/", {
      next: { revalidate: 3600 }, // Cache for 1 hour
    })

    if (!response.ok) throw new Error("Failed to fetch currency rates")

    const data = await response.json()

    // Map main currencies
    const currencies = ["USD", "EUR", "RUB", "CNY", "GBP", "JPY"]

    return data
      .filter((item: any) => currencies.includes(item.Ccy))
      .map((item: any) => ({
        code: item.Ccy,
        name: item.CcyNm_UZ,
        rate: Number.parseFloat(item.Rate),
        change: Number.parseFloat(item.Diff) || 0,
        lastUpdated: item.Date,
      }))
  } catch (error) {
    console.error("[v0] Error fetching currency rates:", error)
    // Return fallback data
    return [
      { code: "USD", name: "US Dollar", rate: 12650, change: 0, lastUpdated: new Date().toISOString() },
      { code: "EUR", name: "Euro", rate: 13450, change: 0, lastUpdated: new Date().toISOString() },
      { code: "RUB", name: "Russian Ruble", rate: 130, change: 0, lastUpdated: new Date().toISOString() },
      { code: "CNY", name: "Chinese Yuan", rate: 1750, change: 0, lastUpdated: new Date().toISOString() },
    ]
  }
}
