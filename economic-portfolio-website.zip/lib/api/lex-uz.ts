export async function fetchLawInfo(type: "tax" | "labor") {
  try {
    const response = await fetch(`/api/laws/${type === "tax" ? "tax-code" : "labor-law"}`)
    const data = await response.json()
    return data
  } catch (error) {
    console.error(`Error fetching ${type} law info:`, error)
    return null
  }
}

export async function searchLaws(query: string) {
  try {
    const response = await fetch(`/api/laws/search?q=${encodeURIComponent(query)}`)
    const data = await response.json()
    return data
  } catch (error) {
    console.error("Error searching laws:", error)
    return null
  }
}
