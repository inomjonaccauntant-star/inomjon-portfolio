import type { StockPrice } from "@/lib/types"

// Demo birja ma'lumotlari
const DEMO_STOCKS: StockPrice[] = [
  {
    id: "gold",
    symbol: "GOLD",
    name_uz: "Tilla narxi",
    name_ru: "Цена золота",
    name_en: "Gold Price",
    name_zh: "黄金价格",
    price: 72500,
    change: 2.5,
    change_percent: 3.8,
    currency: "USD",
    icon: "🪙",
  },
  {
    id: "silver",
    symbol: "SILVER",
    name_uz: "Kumush narxi",
    name_ru: "Цена серебра",
    name_en: "Silver Price",
    name_zh: "白银价格",
    price: 945,
    change: 1.2,
    change_percent: 2.1,
    currency: "USD",
    icon: "💎",
  },
  {
    id: "crude_oil",
    symbol: "CRUDE",
    name_uz: "Xom neft",
    name_ru: "Сырая нефть",
    name_en: "Crude Oil",
    name_zh: "原油",
    price: 85.3,
    change: -1.5,
    change_percent: -1.7,
    currency: "USD",
    icon: "🛢️",
  },
  {
    id: "bitcoin",
    symbol: "BTC",
    name_uz: "Bitcoin",
    name_ru: "Биткоин",
    name_en: "Bitcoin",
    name_zh: "比特币",
    price: 98500,
    change: 5.2,
    change_percent: 5.6,
    currency: "USD",
    icon: "₿",
  },
]

export async function getStockPrices(): Promise<StockPrice[]> {
  try {
    // Real API ga ulash uchun, bu yerda real ma'lumot manbasini qo'shing
    // Hozircha demo ma'lumotlar qaytariladi
    return DEMO_STOCKS
  } catch (error) {
    console.error("[v0] Error fetching stock prices:", error)
    return DEMO_STOCKS
  }
}
