export interface WeatherData {
  city: string
  country: string
  temperature: number
  feelsLike: number
  humidity: number
  windSpeed: number
  description: string
  icon: string
  sunrise: string
  sunset: string
}

export async function getWeather(city = "Fergana"): Promise<WeatherData> {
  try {
    const API_KEY = process.env.OPENWEATHER_API_KEY || "demo"

    if (API_KEY === "demo") {
      console.log("[v0] Using fallback weather data (no API key)")
      return {
        city: "Farg'ona",
        country: "UZ",
        temperature: 22,
        feelsLike: 21,
        humidity: 45,
        windSpeed: 12,
        description: "Ochiq osmon",
        icon: "01d",
        sunrise: "06:30",
        sunset: "18:45",
      }
    }

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city},UZ&units=metric&appid=${API_KEY}`,
      {
        next: { revalidate: 1800 }, // Cache for 30 minutes
      },
    )

    if (!response.ok) {
      throw new Error("Failed to fetch weather")
    }

    const data = await response.json()

    return {
      city: data.name,
      country: data.sys.country,
      temperature: Math.round(data.main.temp),
      feelsLike: Math.round(data.main.feels_like),
      humidity: data.main.humidity,
      windSpeed: Math.round(data.wind.speed * 3.6),
      description: data.weather[0].description,
      icon: data.weather[0].icon,
      sunrise: new Date(data.sys.sunrise * 1000).toLocaleTimeString("uz-UZ", {
        hour: "2-digit",
        minute: "2-digit",
      }),
      sunset: new Date(data.sys.sunset * 1000).toLocaleTimeString("uz-UZ", {
        hour: "2-digit",
        minute: "2-digit",
      }),
    }
  } catch (error) {
    console.error("[v0] Error fetching weather:", error)
    return {
      city: "Farg'ona",
      country: "UZ",
      temperature: 22,
      feelsLike: 21,
      humidity: 45,
      windSpeed: 12,
      description: "Ochiq osmon",
      icon: "01d",
      sunrise: "06:30",
      sunset: "18:45",
    }
  }
}
