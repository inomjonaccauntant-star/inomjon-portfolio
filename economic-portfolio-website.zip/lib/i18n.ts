export const locales = ["uz", "ru", "en", "zh"] as const
export type Locale = (typeof locales)[number]

export const defaultLocale: Locale = "uz"

export const languages = {
  uz: "O'zbekcha",
  ru: "Русский",
  en: "English",
  zh: "中文",
}

export const translations = {
  uz: {
    nav: {
      home: "Bosh sahifa",
      about: "Men haqimda",
      portfolio: "Portfolio",
      blog: "Blog",
      resources: "Resurslar",
      laws: "Qonunchiligi",
      contact: "Aloqa",
    },
    home: {
      hero: {
        title: "Iqtisodiy Tahlil va Portfolio",
        subtitle: "Professional iqtisodchi va tahlilchi",
        cta: "Portfolio ko'rish",
      },
      sections: {
        about: "Men haqimda",
        latestPosts: "So'nggi maqolalar",
        portfolio: "Mening ishlarim",
        quote: "Kun iqtibosi",
        news: "So'nggi yangiliklar",
        weather: "Ob-havo",
        currency: "Valyuta kurslari",
      },
    },
    common: {
      readMore: "Batafsil",
      viewAll: "Barchasini ko'rish",
      loading: "Yuklanmoqda...",
      error: "Xatolik yuz berdi",
      language: "Til",
    },
  },
  ru: {
    nav: {
      home: "Главная",
      about: "Обо мне",
      portfolio: "Портфолио",
      blog: "Блог",
      resources: "Ресурсы",
      laws: "Законодательство",
      contact: "Контакты",
    },
    home: {
      hero: {
        title: "Экономический анализ и портфолио",
        subtitle: "Профессиональный экономист и аналитик",
        cta: "Посмотреть портфолио",
      },
      sections: {
        about: "Обо мне",
        latestPosts: "Последние статьи",
        portfolio: "Мои работы",
        quote: "Цитата дня",
        news: "Последние новости",
        weather: "Погода",
        currency: "Курсы валют",
      },
    },
    common: {
      readMore: "Подробнее",
      viewAll: "Смотреть все",
      loading: "Загрузка...",
      error: "Произошла ошибка",
      language: "Язык",
    },
  },
  en: {
    nav: {
      home: "Home",
      about: "About",
      portfolio: "Portfolio",
      blog: "Blog",
      resources: "Resources",
      laws: "Laws",
      contact: "Contact",
    },
    home: {
      hero: {
        title: "Economic Analysis and Portfolio",
        subtitle: "Professional Economist and Analyst",
        cta: "View Portfolio",
      },
      sections: {
        about: "About Me",
        latestPosts: "Latest Articles",
        portfolio: "My Work",
        quote: "Quote of the Day",
        news: "Latest News",
        weather: "Weather",
        currency: "Exchange Rates",
      },
    },
    common: {
      readMore: "Read More",
      viewAll: "View All",
      loading: "Loading...",
      error: "An error occurred",
      language: "Language",
    },
  },
  zh: {
    nav: {
      home: "主页",
      about: "关于我",
      portfolio: "作品集",
      blog: "博客",
      resources: "资源",
      laws: "法律",
      contact: "联系",
    },
    home: {
      hero: {
        title: "经济分析与作品集",
        subtitle: "专业经济学家和分析师",
        cta: "查看作品集",
      },
      sections: {
        about: "关于我",
        latestPosts: "最新文章",
        portfolio: "我的工作",
        quote: "每日名言",
        news: "最新新闻",
        weather: "天气",
        currency: "汇率",
      },
    },
    common: {
      readMore: "阅读更多",
      viewAll: "查看全部",
      loading: "加载中...",
      error: "发生错误",
      language: "语言",
    },
  },
}

export function getTranslation(locale: Locale) {
  return translations[locale] || translations.uz
}
