export type Locale = "uz" | "ru" | "en" | "zh"

export interface LocalizedContent {
  title_uz: string
  title_ru?: string
  title_en?: string
  title_zh?: string
  description_uz?: string
  description_ru?: string
  description_en?: string
  description_zh?: string
}

export interface Profile {
  id: string
  email: string
  full_name: string
  avatar_url?: string
  bio?: string
  created_at: string
  updated_at: string
}

export interface Portfolio extends LocalizedContent {
  id: string
  user_id: string
  category: string
  tags: string[]
  media_urls: string[]
  thumbnail_url?: string
  project_url?: string
  published: boolean
  views_count: number
  created_at: string
  updated_at: string
}

export interface BlogPost extends LocalizedContent {
  id: string
  user_id: string
  content_uz: string
  content_ru?: string
  content_en?: string
  content_zh?: string
  excerpt_uz?: string
  excerpt_ru?: string
  excerpt_en?: string
  excerpt_zh?: string
  category: string
  tags: string[]
  cover_image_url?: string
  published: boolean
  views_count: number
  reading_time?: number
  created_at: string
  updated_at: string
}

export interface Quote {
  id: string
  author_uz: string
  author_ru?: string
  author_en?: string
  author_zh?: string
  text_uz: string
  text_ru?: string
  text_en?: string
  text_zh?: string
  category?: string
  is_active: boolean
  created_at: string
}

export interface NewsArticle extends LocalizedContent {
  id: string
  content_uz: string
  content_ru?: string
  content_en?: string
  content_zh?: string
  source?: string
  source_url?: string
  category: string
  region?: string
  ai_generated: boolean
  published_at?: string
  created_at: string
}

export interface Resource extends LocalizedContent {
  id: string
  user_id: string
  file_url?: string
  file_type?: string
  category: string
  tags: string[]
  downloads_count: number
  published: boolean
  created_at: string
}

export interface StockPrice {
  id: string
  symbol: string
  name_uz: string
  name_ru: string
  name_en: string
  name_zh: string
  price: number
  change: number
  change_percent: number
  currency: string
  icon: string
}

export interface EconomicStat {
  id: string
  title_uz: string
  title_ru: string
  title_en: string
  title_zh: string
  value: number
  unit_uz: string
  unit_ru: string
  unit_en: string
  unit_zh: string
  growth: number
  icon: string
}

export interface CurrencyRate {
  code: string
  name: string
  rate: number
  change: number
}
