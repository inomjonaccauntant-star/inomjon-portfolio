-- Enable necessary extensions
create extension if not exists "uuid-ossp";

-- Profiles table (user management)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  avatar_url text,
  bio text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_all" on public.profiles for select using (true);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);
create policy "profiles_delete_own" on public.profiles for delete using (auth.uid() = id);

-- Portfolio items table
create table if not exists public.portfolios (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  title_uz text not null,
  title_ru text,
  title_en text,
  title_zh text,
  description_uz text not null,
  description_ru text,
  description_en text,
  description_zh text,
  category text not null,
  tags text[],
  media_urls text[],
  thumbnail_url text,
  project_url text,
  published boolean default false,
  views_count integer default 0,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.portfolios enable row level security;

create policy "portfolios_select_published" on public.portfolios for select using (published = true or auth.uid() = user_id);
create policy "portfolios_insert_own" on public.portfolios for insert with check (auth.uid() = user_id);
create policy "portfolios_update_own" on public.portfolios for update using (auth.uid() = user_id);
create policy "portfolios_delete_own" on public.portfolios for delete using (auth.uid() = user_id);

-- Blog posts table
create table if not exists public.blog_posts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  title_uz text not null,
  title_ru text,
  title_en text,
  title_zh text,
  content_uz text not null,
  content_ru text,
  content_en text,
  content_zh text,
  excerpt_uz text,
  excerpt_ru text,
  excerpt_en text,
  excerpt_zh text,
  category text not null,
  tags text[],
  cover_image_url text,
  published boolean default false,
  views_count integer default 0,
  reading_time integer,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.blog_posts enable row level security;

create policy "blog_posts_select_published" on public.blog_posts for select using (published = true or auth.uid() = user_id);
create policy "blog_posts_insert_own" on public.blog_posts for insert with check (auth.uid() = user_id);
create policy "blog_posts_update_own" on public.blog_posts for update using (auth.uid() = user_id);
create policy "blog_posts_delete_own" on public.blog_posts for delete using (auth.uid() = user_id);

-- Quotes table (hikmatli so'zlar)
create table if not exists public.quotes (
  id uuid primary key default uuid_generate_v4(),
  author_uz text not null,
  author_ru text,
  author_en text,
  author_zh text,
  text_uz text not null,
  text_ru text,
  text_en text,
  text_zh text,
  category text,
  is_active boolean default true,
  created_at timestamp with time zone default now()
);

alter table public.quotes enable row level security;

create policy "quotes_select_all" on public.quotes for select using (is_active = true);
create policy "quotes_insert_auth" on public.quotes for insert with check (auth.uid() is not null);
create policy "quotes_update_auth" on public.quotes for update using (auth.uid() is not null);
create policy "quotes_delete_auth" on public.quotes for delete using (auth.uid() is not null);

-- News articles table (AI-generated)
create table if not exists public.news_articles (
  id uuid primary key default uuid_generate_v4(),
  title_uz text not null,
  title_ru text,
  title_en text,
  title_zh text,
  content_uz text not null,
  content_ru text,
  content_en text,
  content_zh text,
  source text,
  source_url text,
  category text not null,
  region text,
  ai_generated boolean default true,
  published_at timestamp with time zone,
  created_at timestamp with time zone default now()
);

alter table public.news_articles enable row level security;

create policy "news_articles_select_all" on public.news_articles for select using (true);
create policy "news_articles_insert_auth" on public.news_articles for insert with check (auth.uid() is not null);
create policy "news_articles_update_auth" on public.news_articles for update using (auth.uid() is not null);
create policy "news_articles_delete_auth" on public.news_articles for delete using (auth.uid() is not null);

-- Economic resources table (qo'llanmalar va materiallar)
create table if not exists public.resources (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  title_uz text not null,
  title_ru text,
  title_en text,
  title_zh text,
  description_uz text,
  description_ru text,
  description_en text,
  description_zh text,
  file_url text,
  file_type text,
  category text not null,
  tags text[],
  downloads_count integer default 0,
  published boolean default false,
  created_at timestamp with time zone default now()
);

alter table public.resources enable row level security;

create policy "resources_select_published" on public.resources for select using (published = true or auth.uid() = user_id);
create policy "resources_insert_own" on public.resources for insert with check (auth.uid() = user_id);
create policy "resources_update_own" on public.resources for update using (auth.uid() = user_id);
create policy "resources_delete_own" on public.resources for delete using (auth.uid() = user_id);

-- Comments table
create table if not exists public.comments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.profiles(id) on delete cascade,
  post_id uuid references public.blog_posts(id) on delete cascade,
  content text not null,
  author_name text,
  author_email text,
  approved boolean default false,
  created_at timestamp with time zone default now()
);

alter table public.comments enable row level security;

create policy "comments_select_approved" on public.comments for select using (approved = true or auth.uid() = user_id);
create policy "comments_insert_all" on public.comments for insert with check (true);
create policy "comments_update_own" on public.comments for update using (auth.uid() = user_id or auth.uid() is not null);
create policy "comments_delete_own" on public.comments for delete using (auth.uid() = user_id);
