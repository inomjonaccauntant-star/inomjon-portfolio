-- Seed some initial quotes
insert into public.quotes (author_uz, author_ru, author_en, author_zh, text_uz, text_ru, text_en, text_zh, category) values
('Adam Smit', 'Адам Смит', 'Adam Smith', '亚当·斯密', 
'Iqtisodiyot - bu odamlarning o''z manfaatlariga erishish yo''lidagi harakati.', 
'Экономика - это движение людей к достижению своих интересов.',
'Economics is the movement of people towards achieving their interests.',
'经济学是人们实现自身利益的运动。',
'economics'),

('Uorren Baffet', 'Уоррен Баффет', 'Warren Buffett', '沃伦·巴菲特',
'Riskni bilmaslik - riskni qabul qilish emas, balki riskni tushunmaslikdir.',
'Не знать риск - это не принимать риск, а не понимать его.',
'Not knowing risk is not taking risk, but not understanding it.',
'不知道风险不是承担风险，而是不理解风险。',
'investment'),

('Jon Keyns', 'Джон Кейнс', 'John Keynes', '约翰·凯恩斯',
'Bozor uzoq muddatda hammamizni o''ldirishidan oldin, qisqa muddatda yashashimiz kerak.',
'В долгосрочной перспективе рынок убьет нас всех, но в краткосрочной мы должны жить.',
'In the long run, the market will kill us all, but in the short run we must live.',
'从长远来看，市场会杀死我们所有人，但短期内我们必须生存。',
'economics');
